# Économie
- Bois, pierre, fer, céréales, or
- Or non pillable en ville
- Marché avec transport réel
