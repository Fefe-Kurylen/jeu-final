# UI / UX (tech)
- Vue ville / ressources / monde
- Barre basse: carte, armée, alliance, messages
- Rapports bataille intégrés
- Chat global, alliance, privé (traduction)
