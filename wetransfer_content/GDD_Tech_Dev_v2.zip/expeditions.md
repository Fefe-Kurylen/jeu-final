# Expéditions
- Génération: 1/h
- File max 15
- Difficulté x récompenses
- XP proportionnelle
