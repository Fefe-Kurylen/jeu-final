# Combat Engine
- Automatique
- Priorité cible: Élite > Intermédiaire > Basique > Siège
- Triangle: Inf > Cav > Arch > Inf
- Blessés générés
- Siège = état, pas une bataille
