# Backend
- NestJS (API)
- Prisma ORM
- PostgreSQL
- Redis (queues + cache)
- Workers séparés (tick 30s)
- WebSocket (map, chat, events)
