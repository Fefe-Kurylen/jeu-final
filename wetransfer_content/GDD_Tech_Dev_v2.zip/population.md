# Population
- Indicateur de puissance
- Gagnée via bâtiments
- Aucun coût ni consommation
