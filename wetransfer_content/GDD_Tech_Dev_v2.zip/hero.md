# Héros
- Niveau max 30
- 1 point/niveau
- Stats: atk, def, logistique, vitesse
- Bonus max +5%
