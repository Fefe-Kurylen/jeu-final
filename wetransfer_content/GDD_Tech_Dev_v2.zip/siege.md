# Siège
- Mur uniquement destructible par engins
- 10 étoiles dégâts bâtiment = 30 min destruction
- Ville bloquée pendant siège
- Multi-armées autorisées
- Régénération mur: 24h de 0 à 100%
