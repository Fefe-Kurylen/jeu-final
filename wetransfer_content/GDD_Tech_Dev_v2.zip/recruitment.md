# Recrutement
- Caserne: inf + archers
- Écurie: cavalerie
- Atelier: siège
- Temps & coût selon tier
- Consommation nourriture:
  Base 5/h, Inter 10/h, Elite 15/h
