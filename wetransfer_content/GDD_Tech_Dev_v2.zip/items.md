# Objets & Inventaire
- 15 slots hors héros
- Équipements héros
- Consommables: eau, ration, déplacement capitale
- Destruction objets possible
