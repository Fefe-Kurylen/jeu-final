# Règles Serveur
- 5000 joueurs max
- Entrées ouvertes 1 semaine
- Classements: population, attaque, défense, alliance
- Durée serveur: 6 mois
