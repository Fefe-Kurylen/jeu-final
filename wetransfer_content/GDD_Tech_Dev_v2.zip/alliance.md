# Alliances (VERROUILLÉ)

## Création
- Via ambassade (capitale uniquement)
- Chef + rôles

## Diplomatie
- Neutre / Ennemi / Allié
- Max 3 alliés
- Statut visible sur carte

## Bastion d’Alliance
- Constructible à 30 membres
- Coût collectif (ressources envoyées)
- Temps construction: 3 jours après ressources complètes
- Cooldown reconstruction: 7 jours
- Mur = 50x ville mur 20
- Bonus:
  +10% production
  +5% vitesse armées
  +10 transport unités
- Défense armées stockées: +10%
- Destructible (siège ouvert à tous)

## Armées alliées
- Stockage possible chez alliés
- Position sur case adjacente à la ville
