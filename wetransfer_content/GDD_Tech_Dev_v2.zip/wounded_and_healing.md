# Blessés & Soins
- % pertes = blessés
- Soins en tente
- Capacité limitée
- Bloqué en siège
