# Carte Monde
- 140k cases initiales
- Extension dynamique
- Biomes, montagnes, rivières infranchissables
- Vision tour de guet: 100 cases
