# GDD Tech Dev v2 – Référence Code (VERROUILLÉ)

Tick serveur: 30s
Toute action (construction, amélioration, recrutement, expédition) démarre UNIQUEMENT via action joueur.
Aucun système automatique caché.

Domaines verrouillés:
- Combat & ratios
- Unités & stats
- Économie
- Bâtiments
- Héros
- Monde
- Alliances
