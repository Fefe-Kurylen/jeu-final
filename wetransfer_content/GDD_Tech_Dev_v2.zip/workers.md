# Workers (tick 30s)
Ordre:
1. Production ressources
2. Consommation nourriture
3. Avancement constructions
4. Avancement recrutements
5. Soins blessés
6. Régénération mur
7. Expéditions
8. Vérification sièges/raids
Anti double-tick par lock Redis.
