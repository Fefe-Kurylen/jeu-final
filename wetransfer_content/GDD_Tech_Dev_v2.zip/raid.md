# Raid
- Arrêt combat à 70% pertes
- Pillage = 30% transport
- Cooldown ville: 24h
- Pas de pillage d’or
