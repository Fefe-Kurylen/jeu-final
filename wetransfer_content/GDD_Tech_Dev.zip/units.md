# Units
Stats réelles dérivées des étoiles
- 10 étoiles = 125 (atk/def/end)
- Vitesse & transport max 100
