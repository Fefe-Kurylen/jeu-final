# Economy
- Ressources: bois, pierre, fer, céréales, or
- Consommation par unité
