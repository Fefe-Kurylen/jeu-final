# Backend
- NestJS
- Prisma + PostgreSQL
- Redis workers 30s
