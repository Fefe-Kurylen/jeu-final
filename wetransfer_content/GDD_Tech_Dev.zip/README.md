# GDD Tech Dev
Version technique pour développeurs.
