# World Map
- Carte procédurale extensible
- Vision tour de guet: 100 cases
