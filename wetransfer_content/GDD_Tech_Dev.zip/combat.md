# Combat Engine
- Tick: 30s
- Priorité: Elite > Intermédiaire > Basique > Siège
- Triangle: Inf > Cav > Arc > Inf
- Blessés soignables hors siège
