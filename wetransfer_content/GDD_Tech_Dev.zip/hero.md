# Hero
- Niveau max 30
- Points: attaque, défense, logistique, vitesse
- Bonus plafonnés à 5%
