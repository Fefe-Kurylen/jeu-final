import 'dotenv/config';
import { PrismaClient, TerrainType } from '@prisma/client';

const prisma = new PrismaClient();

const WIDTH = 374;
const HEIGHT = 374;
const MIN_X = -Math.floor(WIDTH / 2);
const MAX_X = MIN_X + WIDTH - 1;
const MIN_Y = -Math.floor(HEIGHT / 2);
const MAX_Y = MIN_Y + HEIGHT - 1;

const RES_TOTAL = 30000;
const GOLD_TOTAL = 4000;
const BATCH = 5000;

function randInt(min: number, max: number) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}
function dist2(ax: number, ay: number, bx: number, by: number) {
  const dx = ax - bx;
  const dy = ay - by;
  return dx * dx + dy * dy;
}
function inBounds(x:number,y:number){
  return x>=MIN_X && x<=MAX_X && y>=MIN_Y && y<=MAX_Y;
}
function baseRegionTerrain(x: number, y: number): TerrainType {
  const midX = 0;
  const midY = 0;
  if (y > midY + HEIGHT * 0.15) return 'SNOW';
  if (y < midY - HEIGHT * 0.15) return 'DESERT';
  if (x > midX + WIDTH * 0.15) return 'HILL';
  if (x < midX - WIDTH * 0.15) return 'ROCKY';
  return 'PLAIN';
}

type Tile = { x:number; y:number; terrain:TerrainType; passable:boolean; };

function generateMountainChains(tiles: Map<string, Tile>) {
  const chains = 6;
  for (let c = 0; c < chains; c++) {
    let x = randInt(MIN_X, MAX_X);
    let y = randInt(MIN_Y, MAX_Y);
    const len = randInt(120, 220);
    for (let i = 0; i < len; i++) {
      for (let w = 0; w < randInt(1,2); w++) {
        const xx = x + randInt(-1,1);
        const yy = y + randInt(-1,1);
        if (!inBounds(xx,yy)) continue;
        const key = `${xx},${yy}`;
        const t = tiles.get(key);
        if (!t) continue;
        t.terrain = 'MOUNTAIN';
        t.passable = false;
      }
      x += randInt(-1, 1);
      y += randInt(-1, 1);
      if (!inBounds(x,y)) break;
    }
  }
}

function generateLakesAndRivers(tiles: Map<string, Tile>) {
  const lakes = 18;
  for (let i = 0; i < lakes; i++) {
    const cx = randInt(MIN_X, MAX_X);
    const cy = randInt(MIN_Y, MAX_Y);
    const r = randInt(5, 12);
    for (let x = cx - r; x <= cx + r; x++) {
      for (let y = cy - r; y <= cy + r; y++) {
        if (!inBounds(x,y)) continue;
        if (dist2(x,y,cx,cy) <= r*r && Math.random() < 0.85) {
          const key = `${x},${y}`;
          const t = tiles.get(key);
          if (!t) continue;
          t.terrain = 'LAKE';
          t.passable = false;
        }
      }
    }
  }
  const rivers = 10;
  for (let i = 0; i < rivers; i++) {
    let x = randInt(MIN_X, MAX_X);
    let y = randInt(MIN_Y, MAX_Y);
    const len = randInt(180, 320);
    for (let j = 0; j < len; j++) {
      if (inBounds(x,y)) {
        const key = `${x},${y}`;
        const t = tiles.get(key);
        if (t && t.terrain !== 'MOUNTAIN') {
          t.terrain = 'RIVER';
          t.passable = false;
        }
      }
      x += randInt(-1, 1);
      y += randInt(-1, 1);
      if (!inBounds(x,y)) break;
    }
  }
}

function generateForests(tiles: Map<string, Tile>) {
  const clusters = 120;
  for (let i = 0; i < clusters; i++) {
    const cx = randInt(MIN_X, MAX_X);
    const cy = randInt(MIN_Y, MAX_Y);
    const r = randInt(4, 10);

    for (let x = cx - r; x <= cx + r; x++) {
      for (let y = cy - r; y <= cy + r; y++) {
        if (!inBounds(x,y)) continue;
        if (dist2(x,y,cx,cy) <= r*r && Math.random() < 0.75) {
          const key = `${x},${y}`;
          const t = tiles.get(key);
          if (!t) continue;
          if (!t.passable) continue;
          if (t.terrain === 'DESERT' && Math.random() < 0.7) continue;
          if (t.terrain === 'SNOW' && Math.random() < 0.6) continue;

          t.terrain = 'FOREST';
          t.passable = true;
        }
      }
    }
  }
}

async function upsertWorldState() {
  await prisma.worldState.upsert({
    where: { id: 'world' },
    update: {
      minX: MIN_X, maxX: MAX_X, minY: MIN_Y, maxY: MAX_Y,
      maxPlayers: 5000,
      joinDeadline: new Date(Date.now() + 7*24*3600*1000),
    },
    create: {
      id: 'world',
      minX: MIN_X, maxX: MAX_X, minY: MIN_Y, maxY: MAX_Y,
      maxPlayers: 5000,
      joinDeadline: new Date(Date.now() + 7*24*3600*1000),
    }
  });
}

async function seedTiles() {
  const tiles = new Map<string, Tile>();
  for (let x = MIN_X; x <= MAX_X; x++) {
    for (let y = MIN_Y; y <= MAX_Y; y++) {
      const terrain = baseRegionTerrain(x,y);
      tiles.set(`${x},${y}`, { x, y, terrain, passable: true });
    }
  }
  generateMountainChains(tiles);
  generateLakesAndRivers(tiles);
  generateForests(tiles);

  await prisma.worldTile.deleteMany();
  const rows = Array.from(tiles.values());
  for (let i=0;i<rows.length;i+=BATCH){
    await prisma.worldTile.createMany({ data: rows.slice(i,i+BATCH) });
  }
}

function resourceKindWeighted(): 'wood'|'stone'|'iron'|'food' {
  const r = Math.random();
  if (r < 0.25) return 'wood';
  if (r < 0.50) return 'stone';
  if (r < 0.75) return 'iron';
  return 'food';
}

function pickLevelWithCenterBias(x:number,y:number){
  const d = Math.sqrt(dist2(x,y,0,0));
  const centerR = Math.min(WIDTH, HEIGHT) * 0.18;
  const inCenter = d <= centerR;

  const r = Math.random();
  if (inCenter) {
    if (r < 0.20) return 2;
    if (r < 0.70) return 3;
    return 1;
  } else {
    if (r < 0.55) return 1;
    if (r < 0.90) return 2;
    return 3;
  }
}

async function seedResources() {
  await prisma.resourceNode.deleteMany();

  const passables = await prisma.worldTile.findMany({
    where: { passable: true },
    select: { x: true, y: true, terrain: true }
  });
  const candidates = passables.filter(t => t.terrain !== 'LAKE' && t.terrain !== 'RIVER' && t.terrain !== 'MOUNTAIN');

  const used = new Set<string>();
  const data: any[] = [];

  function reserve(x:number,y:number){ used.add(`${x},${y}`); }
  function isFree(x:number,y:number){ return !used.has(`${x},${y}`); }
  function pick() { return candidates[randInt(0, candidates.length-1)]; }

  while (data.length < RES_TOTAL) {
    const t = pick();
    if (!isFree(t.x,t.y)) continue;
    const kind = resourceKindWeighted();
    const level = pickLevelWithCenterBias(t.x,t.y);
    reserve(t.x,t.y);
    data.push({ x:t.x, y:t.y, kind, level, filledPct:1.0, lastUpdateAt:new Date(), baseTribePower:100*level, tribePower:100*level });
  }

  let g=0;
  while (g < GOLD_TOTAL) {
    const t = pick();
    if (!isFree(t.x,t.y)) continue;
    const level = pickLevelWithCenterBias(t.x,t.y);
    reserve(t.x,t.y);
    data.push({ x:t.x, y:t.y, kind:'gold', level, filledPct:1.0, lastUpdateAt:new Date(), baseTribePower:140*level, tribePower:140*level });
    g++;
  }

  for (let i=0;i<data.length;i+=BATCH){
    await prisma.resourceNode.createMany({ data: data.slice(i,i+BATCH) });
  }
}

async function main() {
  console.log('seed world state');
  await upsertWorldState();
  console.log('seed tiles');
  await seedTiles();
  console.log('seed resources');
  await seedResources();
  console.log('done');
}
main().catch(e=>{console.error(e);process.exit(1)}).finally(async()=>{await prisma.$disconnect()});
