import { ArmySnapshot, BattleContext } from './types';

function pct(n?: number) { return n ?? 0; }

export function computeHeroAttackPct(army: ArmySnapshot): number {
  if (!army.hero) return 0;
  return army.hero.atkPoints * 0.005;
}
export function computeHeroDefensePct(army: ArmySnapshot): number {
  if (!army.hero) return 0;
  return army.hero.defPoints * 0.005;
}
export function computeHeroLossReductionPct(army: ArmySnapshot): number {
  return army.hero?.lossReductionPct ?? 0;
}

export function computeFactionAttackPct(
  side: 'ATTACKER'|'DEFENDER',
  _army: ArmySnapshot,
  ctx: BattleContext,
): number {
  const b = side === 'ATTACKER' ? ctx.attackerFactionBonus : ctx.defenderFactionBonus;
  if (!b) return 0;

  let total = pct(b.attackPct);
  if (side === 'ATTACKER' && ctx.mode === 'CITY_ATTACK') total += pct(b.attackWhenAttackingCityPct);
  if (side === 'DEFENDER' && ctx.mode === 'CITY_DEFENSE' && ctx.isSiegeState) total += pct(b.attackWhenDefendingSiegePct);
  return total;
}

export function computeFactionDefensePct(
  side: 'ATTACKER'|'DEFENDER',
  _army: ArmySnapshot,
  ctx: BattleContext,
): number {
  const b = side === 'ATTACKER' ? ctx.attackerFactionBonus : ctx.defenderFactionBonus;
  if (!b) return 0;

  let total = pct(b.defensePct);
  if (side === 'ATTACKER') total += pct(b.defenseWhenAttackingPct);
  if (side === 'DEFENDER' && ctx.mode === 'FIELD') total += pct(b.defenseWhenAttackedOutsideCityPct);
  return total;
}

export function computeLossReductionPct(
  side: 'ATTACKER'|'DEFENDER',
  army: ArmySnapshot,
  ctx: BattleContext,
): number {
  const b = side === 'ATTACKER' ? ctx.attackerFactionBonus : ctx.defenderFactionBonus;
  let total = computeHeroLossReductionPct(army);

  if (b?.lossReductionCityDefensePct && side === 'DEFENDER' && ctx.mode === 'CITY_DEFENSE') total += b.lossReductionCityDefensePct;
  if (b?.lossReductionCityDefensePct && side === 'ATTACKER' && ctx.mode === 'CITY_ATTACK') total += b.lossReductionCityDefensePct;

  return Math.max(0, Math.min(total, 0.25));
}
