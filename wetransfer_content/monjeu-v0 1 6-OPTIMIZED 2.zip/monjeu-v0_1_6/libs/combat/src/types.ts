export type Tier = 'base' | 'intermediate' | 'elite' | 'siege';

export interface UnitStats {
  attack: number;
  defense: number;
  endurance: number;
  speed: number;
  transport: number;
}

export interface UnitDef {
  key: string;
  tier: Tier;
  stats: UnitStats;
}

export interface Stack {
  unitKey: string;
  tier: Tier;
  count: number;
}

export interface ArmySnapshot {
  armyId: string;
  playerId: string;
  faction: 'ROME'|'GAUL'|'GREEK'|'EGYPT'|'HUN'|'SULTAN';
  stacks: Stack[];
  hero?: HeroSnapshot;
}

export interface HeroSnapshot {
  level: number;
  atkPoints: number;
  defPoints: number;
  logPoints: number;
  spdPoints: number;
  lossReductionPct?: number;
}

export type BattleMode = 'FIELD' | 'CITY_DEFENSE' | 'CITY_ATTACK' | 'RAID';

export interface BattleContext {
  mode: BattleMode;
  isSiegeState: boolean;
  defenderInCity: boolean;
  attackerInCity: boolean;
  attackerFactionBonus?: FactionBonuses;
  defenderFactionBonus?: FactionBonuses;
}

export interface FactionBonuses {
  attackPct?: number;
  defensePct?: number;
  attackWhenAttackingCityPct?: number;
  defenseWhenAttackedOutsideCityPct?: number;
  attackWhenDefendingSiegePct?: number;
  defenseWhenAttackingPct?: number;
  lossReductionCityDefensePct?: number;
}

export interface BattleResultSide {
  playerId: string;
  armyId: string;
  remaining: Stack[];
  killed: Record<string, number>;
  wounded: Record<string, number>;
}

export interface BattleResult {
  rounds: number;
  winner: 'ATTACKER'|'DEFENDER'|'DRAW';
  attacker: BattleResultSide;
  defender: BattleResultSide;
  log: Array<{ round: number; attackerLoss: number; defenderLoss: number }>;
  /**
   * Optional technical audit information to debug balance and modifiers.
   * This is safe to store in the DB as JSON and is intended for developers.
   */
  audit?: {
    initial: { attackerUnits: number; defenderUnits: number };
    raidStop?: { attackerStopAt: number; defenderStopAt: number };
    modifiers: {
      attackerAttackPct: number;
      attackerDefensePct: number;
      attackerLossReductionPct: number;
      defenderAttackPct: number;
      defenderDefensePct: number;
      defenderLossReductionPct: number;
    };
    rounds: Array<{
      round: number;
      atkKillsRaw: number;
      defKillsRaw: number;
      atkKillsApplied: number;
      defKillsApplied: number;
      attackerRemaining: number;
      defenderRemaining: number;
    }>;
  };
}
