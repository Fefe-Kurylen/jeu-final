import { ArmySnapshot, BattleContext, BattleResult, BattleResultSide, Stack, UnitDef } from './types';
import { DAMAGE_DEF_MULT, MAX_ROUNDS, TIER_COEFF, tierPriority, WOUNDED_RATE } from './config';
import { computeFactionAttackPct, computeFactionDefensePct, computeHeroAttackPct, computeHeroDefensePct, computeLossReductionPct } from './bonuses';

export interface UnitRegistry {
  getUnit(unitKey: string): UnitDef;
}

function cloneStacks(stacks: Stack[]): Stack[] { return stacks.map(s => ({ ...s })); }
function sortTargetStacks(stacks: Stack[]): Stack[] {
  return cloneStacks(stacks).filter(s => s.count > 0).sort((a,b)=>tierPriority(a.tier)-tierPriority(b.tier));
}
function sumCounts(stacks: Stack[]) { return stacks.reduce((a,s)=>a+s.count,0); }
function applyLossReduction(losses:number, reductionPct:number){ return Math.floor(losses*(1-reductionPct)); }

function computeEffectiveAttack(unit: UnitDef, atkPct:number){ return unit.stats.attack * TIER_COEFF[unit.tier] * (1+atkPct); }
function computeEffectiveDefense(unit: UnitDef, defPct:number){ return unit.stats.defense * TIER_COEFF[unit.tier] * (1+defPct); }

function computeKillBudgetForSide(
  registry: UnitRegistry,
  attackerStacks: Stack[],
  defenderStacks: Stack[],
  atkPct:number,
  defPct:number
): number {
  let power=0;
  for (const s of attackerStacks){
    if (s.count<=0) continue;
    const u = registry.getUnit(s.unitKey);
    power += computeEffectiveAttack(u, atkPct) * s.count;
  }
  let tank=0; let enemyUnits=0;
  for (const s of defenderStacks){
    if (s.count<=0) continue;
    const u = registry.getUnit(s.unitKey);
    const def = computeEffectiveDefense(u, defPct);
    const tankiness = u.stats.endurance + def*DAMAGE_DEF_MULT;
    tank += tankiness * s.count;
    enemyUnits += s.count;
  }
  if (enemyUnits<=0) return 0;
  const avgTank = tank / enemyUnits;
  return Math.max(0, Math.floor(power / Math.max(1, avgTank)));
}

function dealDamageToTargets(defenderStacks: Stack[], budgetKills:number): Record<string, number> {
  const killed: Record<string, number> = {};
  let remainingBudget = budgetKills;
  const targets = sortTargetStacks(defenderStacks);
  for (const t of targets){
    if (remainingBudget<=0) break;
    const take = Math.min(t.count, remainingBudget);
    if (take>0){
      killed[t.unitKey] = (killed[t.unitKey]??0) + take;
      t.count -= take;
      remainingBudget -= take;
    }
  }
  for (const t of targets){
    const idx = defenderStacks.findIndex(s=>s.unitKey===t.unitKey);
    if (idx>=0) defenderStacks[idx].count = t.count;
  }
  return killed;
}

function toWounded(killed: Record<string, number>) {
  const wounded: Record<string, number> = {};
  const dead: Record<string, number> = {};
  for (const k of Object.keys(killed)){
    const total = killed[k];
    const w = Math.floor(total * WOUNDED_RATE);
    wounded[k]=w;
    dead[k]=total-w;
  }
  return { wounded, dead };
}

export function simulateBattle(
  registry: UnitRegistry,
  attacker: ArmySnapshot,
  defender: ArmySnapshot,
  ctx: BattleContext
): BattleResult {
  const atkStacks = cloneStacks(attacker.stacks);
  const defStacks = cloneStacks(defender.stacks);

  const atkInitial = sumCounts(atkStacks);
  const defInitial = sumCounts(defStacks);
  const raidStopAtk = Math.ceil(atkInitial * 0.7);
  const raidStopDef = Math.ceil(defInitial * 0.7);

  const log: BattleResult['log'] = [];

  const atkAtkPct = computeHeroAttackPct(attacker) + computeFactionAttackPct('ATTACKER', attacker, ctx);
  const defDefPct = computeHeroDefensePct(defender) + computeFactionDefensePct('DEFENDER', defender, ctx);

  const defAtkPct = computeHeroAttackPct(defender) + computeFactionAttackPct('DEFENDER', defender, ctx);
  const atkDefPct = computeHeroDefensePct(attacker) + computeFactionDefensePct('ATTACKER', attacker, ctx);

  const atkLossRed = computeLossReductionPct('ATTACKER', attacker, ctx);
  const defLossRed = computeLossReductionPct('DEFENDER', defender, ctx);

  const audit: NonNullable<BattleResult['audit']> = {
    initial: { attackerUnits: atkInitial, defenderUnits: defInitial },
    raidStop: ctx.mode === 'RAID' ? { attackerStopAt: raidStopAtk, defenderStopAt: raidStopDef } : undefined,
    modifiers: {
      attackerAttackPct: atkAtkPct,
      attackerDefensePct: atkDefPct,
      attackerLossReductionPct: atkLossRed,
      defenderAttackPct: defAtkPct,
      defenderDefensePct: defDefPct,
      defenderLossReductionPct: defLossRed,
    },
    rounds: [],
  };

  let rounds=0;

  const atkKilledCum: Record<string, number> = {};
  const defKilledCum: Record<string, number> = {};
  const atkWoundedCum: Record<string, number> = {};
  const defWoundedCum: Record<string, number> = {};

  while (rounds < MAX_ROUNDS && sumCounts(atkStacks)>0 && sumCounts(defStacks)>0){
    rounds++;

    const atkKillsRaw = computeKillBudgetForSide(registry, atkStacks, defStacks, atkAtkPct, defDefPct);
    const defKillsRaw = computeKillBudgetForSide(registry, defStacks, atkStacks, defAtkPct, atkDefPct);

    const atkKills = applyLossReduction(atkKillsRaw, defLossRed);
    const defKills = applyLossReduction(defKillsRaw, atkLossRed);

    // If the computed budget is 0, no kills this round. MAX_ROUNDS prevents infinite fights.
    const killedOnDef = dealDamageToTargets(defStacks, Math.max(0, atkKills));
    const killedOnAtk = dealDamageToTargets(atkStacks, Math.max(0, defKills));

    const defSplit = toWounded(killedOnDef);
    const atkSplit = toWounded(killedOnAtk);

    for (const k of Object.keys(defSplit.dead)) defKilledCum[k]=(defKilledCum[k]??0)+defSplit.dead[k];
    for (const k of Object.keys(defSplit.wounded)) defWoundedCum[k]=(defWoundedCum[k]??0)+defSplit.wounded[k];

    for (const k of Object.keys(atkSplit.dead)) atkKilledCum[k]=(atkKilledCum[k]??0)+atkSplit.dead[k];
    for (const k of Object.keys(atkSplit.wounded)) atkWoundedCum[k]=(atkWoundedCum[k]??0)+atkSplit.wounded[k];

    log.push({
      round: rounds,
      attackerLoss: Object.values(atkSplit.dead).reduce((a,b)=>a+b,0)+Object.values(atkSplit.wounded).reduce((a,b)=>a+b,0),
      defenderLoss: Object.values(defSplit.dead).reduce((a,b)=>a+b,0)+Object.values(defSplit.wounded).reduce((a,b)=>a+b,0),
    });

    audit.rounds.push({
      round: rounds,
      atkKillsRaw,
      defKillsRaw,
      atkKillsApplied: Math.max(0, atkKills),
      defKillsApplied: Math.max(0, defKills),
      attackerRemaining: sumCounts(atkStacks),
      defenderRemaining: sumCounts(defStacks),
    });

    if (ctx.mode === 'RAID') {
      // Stop rule for raid: first side hitting <=70% remaining ends the combat.
      if (sumCounts(atkStacks) <= raidStopAtk || sumCounts(defStacks) <= raidStopDef) break;
    }
  }

  let winner: BattleResult['winner']='DRAW';
  if (sumCounts(atkStacks)>0 && sumCounts(defStacks)<=0) winner='ATTACKER';
  else if (sumCounts(defStacks)>0 && sumCounts(atkStacks)<=0) winner='DEFENDER';
  else if (ctx.mode === 'RAID') {
    // RAID winner = side with more remaining units at stop time.
    const a = sumCounts(atkStacks);
    const d = sumCounts(defStacks);
    if (a > d) winner = 'ATTACKER';
    else if (d > a) winner = 'DEFENDER';
    else winner = 'DRAW';
  }

  const attackerSide: BattleResultSide = { playerId: attacker.playerId, armyId: attacker.armyId, remaining: atkStacks.filter(s=>s.count>0), killed: defKilledCum, wounded: defWoundedCum };
  const defenderSide: BattleResultSide = { playerId: defender.playerId, armyId: defender.armyId, remaining: defStacks.filter(s=>s.count>0), killed: atkKilledCum, wounded: atkWoundedCum };

  return { rounds, winner, attacker: attackerSide, defender: defenderSide, log, audit };
}
