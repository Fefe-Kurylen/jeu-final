export const RUNTIME_BUILDINGS: any = {};
