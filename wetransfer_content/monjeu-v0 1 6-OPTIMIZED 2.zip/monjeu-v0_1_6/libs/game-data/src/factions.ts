import { FactionBonuses } from '@libs/combat/src/types';

// ⚠️ Alpha: bonus faction minimal. Ajuste avec tes valeurs finales.
export const FACTION_BONUSES: Record<string, FactionBonuses> = {
  ROME:  { defenseWhenAttackingPct: 0.10, lossReductionCityDefensePct: 0.10 },
  GAUL:  { attackWhenDefendingSiegePct: 0.10 },
  GREEK: { defenseWhenAttackedOutsideCityPct: 0.10 },
  EGYPT: { attackWhenDefendingSiegePct: 0.10 },
  HUN:   { attackWhenAttackingCityPct: 0.10 },
  SULTAN:{ },
};
