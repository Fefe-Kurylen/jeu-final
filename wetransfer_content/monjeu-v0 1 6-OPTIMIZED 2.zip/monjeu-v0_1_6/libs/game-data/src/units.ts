import { UnitDef } from '@libs/combat/src/types';

// ⚠️ Alpha: dataset minimal pour compiler. Remplace/complète avec toutes tes unités finales.
export const UNIT_BY_KEY: Record<string, UnitDef> = {
  ROM_MILICIEN: { key:'ROM_MILICIEN', tier:'base', stats:{ attack:30, defense:40, endurance:40, speed:50, transport:70 } },
  ROM_TRIARII:  { key:'ROM_TRIARII',  tier:'intermediate', stats:{ attack:50, defense:70, endurance:60, speed:40, transport:60 } },
  ROM_LEGION:   { key:'ROM_LEGION',   tier:'elite', stats:{ attack:70, defense:60, endurance:80, speed:40, transport:40 } },
  ROM_CATAPULT: { key:'ROM_CATAPULT', tier:'siege', stats:{ attack:20, defense:10, endurance:50, speed:10, transport:30 } },

  HUN_NOMADE:   { key:'HUN_NOMADE',   tier:'intermediate', stats:{ attack:55, defense:35, endurance:55, speed:55, transport:55 } },
  HUN_ELITE:    { key:'HUN_ELITE',    tier:'elite', stats:{ attack:80, defense:50, endurance:70, speed:50, transport:40 } },
};
