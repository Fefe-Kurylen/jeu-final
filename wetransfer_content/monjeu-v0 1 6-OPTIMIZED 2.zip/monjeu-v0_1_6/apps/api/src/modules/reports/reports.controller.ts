import { Controller, Get, UseGuards } from '@nestjs/common';
import { PrismaService } from '../../common/prisma/prisma.service';
import { JwtAuthGuard } from '../auth/jwt.guard';
import { CurrentPlayer } from '../../common/auth/current-player.decorator';

@Controller('reports')
@UseGuards(JwtAuthGuard)
export class ReportsController {
  constructor(private prisma: PrismaService) {}

  @Get('battles')
  battles(@CurrentPlayer() u:{playerId:string}){
    return this.prisma.battleReport.findMany({ where:{ OR:[{attackerId:u.playerId},{defenderId:u.playerId}] }, orderBy:{createdAt:'desc'}, take:50 });
  }

  @Get('spies')
  spies(@CurrentPlayer() u:{playerId:string}){
    return this.prisma.spyReport.findMany({ where:{ attackerId:u.playerId }, orderBy:{createdAt:'desc'}, take:50 });
  }
}
