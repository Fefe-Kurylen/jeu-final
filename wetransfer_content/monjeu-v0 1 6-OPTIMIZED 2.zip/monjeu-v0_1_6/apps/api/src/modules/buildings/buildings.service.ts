import { BadRequestException, Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { PrismaService } from '../../common/prisma/prisma.service';
import { loadBuildingsFromJson, costAtLevel, timeAtLevelSec } from '@libs/game-data/src/loader';

const DATA_BUILDINGS_PATH = process.env.DATA_BUILDINGS_PATH ?? 'data/buildings.json';

function safeLoadBuildings(){
  return loadBuildingsFromJson(DATA_BUILDINGS_PATH);
}

const BUILDINGS = safeLoadBuildings();

function hasResources(city:any, cost:any){
  return city.wood>=cost.wood && city.stone>=cost.stone && city.iron>=cost.iron && city.food>=cost.food;
}

@Injectable()
export class BuildingsService {
  constructor(private prisma: PrismaService){}

  async getCityBuildings(playerId:string, cityId:string){
    const city = await this.prisma.city.findUnique({ where:{ id: cityId }, include:{ buildings:true, buildQueue:true }});
    if (!city) throw new NotFoundException('City not found');
    if (city.ownerId !== playerId) throw new ForbiddenException();
    return city;
  }

  async startBuild(playerId:string, cityId:string, buildingKey:string, queue: 1|2|3|4){
    const def = (BUILDINGS as any)[buildingKey];
    if (!def) throw new BadRequestException('Unknown buildingKey');

    const city = await this.prisma.city.findUnique({ where:{ id: cityId }, include:{ buildings:true, buildQueue:true }});
    if (!city) throw new NotFoundException('City not found');
    if (city.ownerId !== playerId) throw new ForbiddenException();

    // enforce queue rules: 2 running (slots 1-2), 2 queued (slots 3-4)
    if (![1,2,3,4].includes(queue)) throw new BadRequestException('Invalid queue');
    const runningCount = city.buildQueue.filter((q:any)=>q.status==='RUNNING').length;
    const queuedCount  = city.buildQueue.filter((q:any)=>q.status==='QUEUED').length;

    if (queue<=2 && runningCount>=2) throw new BadRequestException('Two constructions already running');
    if (queue>=3 && queuedCount>=2) throw new BadRequestException('Queue is full');

    const existing = city.buildings.find((b:any)=>b.key===buildingKey);
    const currentLevel = existing?.level ?? 0;
    const targetLevel = currentLevel + 1;
    if (targetLevel>def.maxLevel) throw new BadRequestException('Max level reached');

    // main hall cap: no building can exceed main hall level
    const main = city.buildings.find((b:any)=>b.key==='MAIN_HALL')?.level ?? 0;
    if (buildingKey!=='MAIN_HALL' && targetLevel>main) throw new BadRequestException('Cannot exceed MAIN_HALL level');

    // chain rule: MAIN_HALL level requires RALLY_POINT same level; RALLY_POINT requires MARKET same level
    if (buildingKey==='MAIN_HALL'){
      const rp = city.buildings.find((b:any)=>b.key==='RALLY_POINT')?.level ?? 0;
      if (rp < targetLevel) throw new BadRequestException('RALLY_POINT must be at least same level as MAIN_HALL');
    }
    if (buildingKey==='RALLY_POINT'){
      const mk = city.buildings.find((b:any)=>b.key==='MARKET')?.level ?? 0;
      if (mk < targetLevel) throw new BadRequestException('MARKET must be at least same level as RALLY_POINT');
    }

    // prereqs
    for (const pr of def.prereq ?? []){
      const lvl = city.buildings.find((b:any)=>b.key===pr.key)?.level ?? 0;
      if (lvl < pr.level) throw new BadRequestException(`Missing prereq ${pr.key} lvl ${pr.level}`);
    }

    const cost = costAtLevel(def, targetLevel);

    if (!hasResources(city, cost)) throw new BadRequestException('Not enough resources');

    // pay resources immediately
    const now = new Date();

    // if queued, placeholder times; will be recalculated when starting
    const duration = timeAtLevelSec(def, targetLevel);
    const endsAt = new Date(now.getTime() + duration*1000);

    const status = (queue<=2) ? 'RUNNING' : 'QUEUED';

    // ensure chosen slot isn't already used
    const slotUsed = city.buildQueue.some((q:any)=>q.slot===queue && (q.status==='RUNNING' || q.status==='QUEUED'));
    if (slotUsed) throw new BadRequestException('Selected slot is already occupied');

    const item = await this.prisma.$transaction(async (tx)=>{
      await tx.city.update({
        where:{ id: city.id },
        data:{
          wood:  { decrement: cost.wood },
          stone: { decrement: cost.stone },
          iron:  { decrement: cost.iron },
          food:  { decrement: cost.food },
        }
      });

      return tx.buildQueueItem.create({
        data:{
          cityId: city.id,
          slot: queue,
          buildingKey,
          targetLevel,
          startedAt: now,
          endsAt: status==='RUNNING' ? endsAt : now, // placeholder
          status,
        }
      });
    });

    return { ok:true, item, cost, durationSec: duration };
  }

  async cancel(playerId:string, cityId:string, queueItemId:string){
    const city = await this.prisma.city.findUnique({ where:{ id: cityId }});
    if (!city) throw new NotFoundException('City not found');
    if (city.ownerId !== playerId) throw new ForbiddenException();

    const item = await this.prisma.buildQueueItem.findUnique({ where:{ id: queueItemId }});
    if (!item || item.cityId!==cityId) throw new NotFoundException('Queue item not found');
    if (item.status==='DONE') throw new BadRequestException('Cannot cancel DONE item');

    await this.prisma.buildQueueItem.delete({ where:{ id: queueItemId }});
    return { ok:true };
  }
}
