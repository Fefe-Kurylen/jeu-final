import { Body, Controller, Get, Param, Post, UseGuards } from '@nestjs/common';
import { JwtGuard } from '../auth/jwt.guard';
import { CurrentPlayer } from '../../common/auth/current-player.decorator';
import { BuildingsService } from './buildings.service';

@Controller('cities/:cityId/buildings')
@UseGuards(JwtGuard)
export class BuildingsController {
  constructor(private svc: BuildingsService){}

  @Get()
  async getCityBuildings(@Param('cityId') cityId: string, @CurrentPlayer() p: any){
    return this.svc.getCityBuildings(p.id, cityId);
  }

  @Post('start')
  async startBuild(
    @Param('cityId') cityId: string,
    @CurrentPlayer() p: any,
    @Body() body: { buildingKey: string; queue: 1|2|3|4; }
  ){
    return this.svc.startBuild(p.id, cityId, body.buildingKey, body.queue);
  }

  @Post('cancel')
  async cancel(@Param('cityId') cityId: string, @CurrentPlayer() p:any, @Body() body:{ queueItemId: string }){
    return this.svc.cancel(p.id, cityId, body.queueItemId);
  }
}
