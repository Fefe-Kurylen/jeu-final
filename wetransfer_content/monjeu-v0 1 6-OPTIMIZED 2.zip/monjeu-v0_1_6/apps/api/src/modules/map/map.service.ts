import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../common/prisma/prisma.service';

@Injectable()
export class MapService {
  constructor(private prisma: PrismaService) {}
  async getViewport(_playerId:string, x:number, y:number, zoom:number){
    const radius = zoom===1 ? 10 : zoom===2 ? 25 : 50;
    const tiles = await this.prisma.worldTile.findMany({ where:{ x:{gte:x-radius,lte:x+radius}, y:{gte:y-radius,lte:y+radius} }, select:{x:true,y:true,terrain:true,passable:true} });
    const cities = await this.prisma.city.findMany({ where:{ x:{gte:x-radius,lte:x+radius}, y:{gte:y-radius,lte:y+radius} }, select:{x:true,y:true,type:true,ownerId:true,isSieged:true} });
    const nodes = await this.prisma.resourceNode.findMany({ where:{ x:{gte:x-radius,lte:x+radius}, y:{gte:y-radius,lte:y+radius} }, select:{x:true,y:true,kind:true,level:true} });
    return { radius, tiles, cities, nodes };
  }
}
