import { Controller, Get, Query, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/jwt.guard';
import { MapService } from './map.service';
import { CurrentPlayer } from '../../common/auth/current-player.decorator';

@Controller('map')
@UseGuards(JwtAuthGuard)
export class MapController {
  constructor(private map: MapService) {}
  @Get('viewport')
  viewport(@CurrentPlayer() u:{playerId:string}, @Query('x') x:string, @Query('y') y:string, @Query('zoom') zoom:string){
    return this.map.getViewport(u.playerId, Number(x), Number(y), Number(zoom));
  }
}
