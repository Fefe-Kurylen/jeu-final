import { Module } from '@nestjs/common';
import { ArmyController } from './army.controller';
@Module({ controllers:[ArmyController] })
export class ArmyModule {}
