import { Injectable, UnauthorizedException } from '@nestjs/common';
import { PrismaService } from '../../common/prisma/prisma.service';
import * as bcrypt from 'bcrypt';
import { JwtService } from '@nestjs/jwt';

@Injectable()
export class AuthService {
  constructor(private prisma: PrismaService, private jwt: JwtService) {}

  async register(email: string, password: string, name: string, faction: string) {
    const passHash = await bcrypt.hash(password, 10);
    const account = await this.prisma.account.create({ data: { email, passHash } });
    const player = await this.prisma.player.create({ data: { accountId: account.id, name, faction: faction as any } });
    await this.prisma.hero.create({ data: { ownerId: player.id } });
    return { ok: true };
  }

  async login(email: string, password: string) {
    const account = await this.prisma.account.findUnique({ where: { email }, include: { player: true } });
    if (!account?.player) throw new UnauthorizedException('bad credentials');
    const ok = await bcrypt.compare(password, account.passHash);
    if (!ok) throw new UnauthorizedException('bad credentials');
    const token = await this.jwt.signAsync({ sub: account.player.id });
    return { token };
  }
}
