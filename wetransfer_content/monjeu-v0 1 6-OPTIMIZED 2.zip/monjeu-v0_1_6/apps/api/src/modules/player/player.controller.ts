import { Controller, Post, UseGuards } from '@nestjs/common';
import { PrismaService } from '../../common/prisma/prisma.service';
import { JwtAuthGuard } from '../auth/jwt.guard';
import { CurrentPlayer } from '../../common/auth/current-player.decorator';

@Controller('player')
@UseGuards(JwtAuthGuard)
export class PlayerController {
  constructor(private prisma: PrismaService) {}

  @Post('bootstrap')
  async bootstrap(@CurrentPlayer() u: { playerId: string }) {
    const player = await this.prisma.player.findUnique({ where: { id: u.playerId }, include: { cities: true } });
    if (!player) throw new Error('player not found');
    if (player.cities.length > 0) return { ok: true, cityId: player.cities[0].id };

    const world = await this.prisma.worldState.findUnique({ where: { id: 'world' } });
    if (!world) throw new Error('world not seeded');

    const edge = Math.floor(Math.random()*4);
    let x=0,y=0;
    if (edge===0){ x=world.minX; y=Math.floor(Math.random()*(world.maxY-world.minY))+world.minY; }
    if (edge===1){ x=world.maxX; y=Math.floor(Math.random()*(world.maxY-world.minY))+world.minY; }
    if (edge===2){ y=world.minY; x=Math.floor(Math.random()*(world.maxX-world.minX))+world.minX; }
    if (edge===3){ y=world.maxY; x=Math.floor(Math.random()*(world.maxX-world.minX))+world.minX; }

    const tile = await this.prisma.worldTile.findFirst({ where: { x, y, passable: true } });
    if (!tile) throw new Error('no spawn tile found');

    const city = await this.prisma.city.create({
      data: {
        ownerId: player.id,
        type: 'CAPITAL',
        x: tile.x,
        y: tile.y,
        name: `${player.name} - Capitale`,
        wood: 500, stone: 500, iron: 500, food: 500,
        buildings: { createMany: { data: [
          { key:'MAIN_BUILDING', level:1, category:'BASE', prodPerHour:0 },
          { key:'RALLY_POINT', level:1, category:'INTERMEDIATE', prodPerHour:0 },
          { key:'BARRACKS', level:1, category:'INTERMEDIATE', prodPerHour:0 },
          { key:'WALL', level:1, category:'ADVANCED', prodPerHour:0 },
          { key:'HEALING_TENT', level:1, category:'INTERMEDIATE', prodPerHour:0 },
        ]}}
      },
    });

    const army = await this.prisma.army.create({
      data: { ownerId: player.id, cityId: city.id, x: city.x, y: city.y, originCityId: city.id, status:'IN_CITY' },
    });

    await this.prisma.armyUnit.createMany({ data: [{ armyId: army.id, unitKey:'ROM_MILICIEN', tier:'base', count: 50 }] });

    return { ok: true, cityId: city.id, armyId: army.id };
  }
}
