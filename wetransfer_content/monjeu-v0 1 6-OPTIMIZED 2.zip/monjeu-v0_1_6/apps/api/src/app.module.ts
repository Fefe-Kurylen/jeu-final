import { Module } from '@nestjs/common';
import { PrismaModule } from './common/prisma/prisma.module';
import { AuthModule } from './modules/auth/auth.module';
import { PlayerModule } from './modules/player/player.module';
import { MapModule } from './modules/map/map.module';
import { CityModule } from './modules/city/city.module';
import { ArmyModule } from './modules/army/army.module';
import { ReportsModule } from './modules/reports/reports.module';
import { BuildingsModule } from './modules/buildings/buildings.module';

@Module({
  imports: [PrismaModule, AuthModule, PlayerModule, MapModule, CityModule, ArmyModule, ReportsModule],
})
export class AppModule {}
