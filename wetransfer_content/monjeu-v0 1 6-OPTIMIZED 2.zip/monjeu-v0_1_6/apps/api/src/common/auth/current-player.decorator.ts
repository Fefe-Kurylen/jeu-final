import { createParamDecorator, ExecutionContext } from '@nestjs/common';
export const CurrentPlayer = createParamDecorator((_d: unknown, ctx: ExecutionContext) => {
  const req = ctx.switchToHttp().getRequest();
  return req.user as { playerId: string };
});
