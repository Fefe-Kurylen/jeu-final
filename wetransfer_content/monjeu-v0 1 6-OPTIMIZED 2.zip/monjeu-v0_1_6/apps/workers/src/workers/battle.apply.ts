import { PrismaService } from '../common/prisma/prisma.service';
import { BattleResult } from '@libs/combat/src/types';

export async function applyBattleResultToDb(
  prisma: PrismaService,
  result: BattleResult,
  context: { type: 'FIELD'|'CITY_ATTACK'|'CITY_DEFENSE'|'RAID'; defenderCityId?: string; attackerId: string; defenderId: string; attackerArmyId: string; defenderArmyId: string; }
) {
  await prisma.$transaction(async (tx) => {
    await applySideLosses(tx, context.attackerArmyId, result.defender.killed, result.defender.wounded, context.defenderCityId, context.type==='CITY_DEFENSE');
    await applySideLosses(tx, context.defenderArmyId, result.attacker.killed, result.attacker.wounded, context.defenderCityId, context.type==='CITY_DEFENSE');

    await cleanupArmy(tx, context.attackerArmyId);
    await cleanupArmy(tx, context.defenderArmyId);

    await tx.battleReport.create({
      data: {
        type: context.type,
        winner: result.winner,
        attackerId: context.attackerId,
        defenderId: context.defenderId,
        attackerArmyId: context.attackerArmyId,
        defenderArmyId: context.defenderArmyId,
        rounds: result.rounds,
        payload: {
          rounds: result.rounds,
          winner: result.winner,
          attacker: { remaining: result.attacker.remaining, killed: result.attacker.killed, wounded: result.attacker.wounded },
          defender: { remaining: result.defender.remaining, killed: result.defender.killed, wounded: result.defender.wounded },
          log: result.log,
          audit: result.audit ?? undefined,
        },
      }
    });
  });
}

async function applySideLosses(
  tx: any,
  armyId: string,
  killed: Record<string, number>,
  wounded: Record<string, number>,
  defenderCityId?: string,
  isCityDefense?: boolean
) {
  for (const unitKey of Object.keys(killed)) {
    await tx.armyUnit.updateMany({ where: { armyId, unitKey }, data: { count: { decrement: killed[unitKey] } } });
  }
  if (defenderCityId && isCityDefense) {
    for (const unitKey of Object.keys(wounded)) {
      await tx.woundedUnit.upsert({
        where: { cityId_unitKey: { cityId: defenderCityId, unitKey } },
        update: { count: { increment: wounded[unitKey] } },
        create: { cityId: defenderCityId, unitKey, count: wounded[unitKey] },
      });
    }
  }
}

async function cleanupArmy(tx:any, armyId:string){
  const units = await tx.armyUnit.findMany({ where:{ armyId } });
  const remaining = units.reduce((a:any,u:any)=>a+u.count,0);
  if (remaining<=0){
    await tx.army.delete({ where:{ id:armyId } });
  } else {
    await tx.army.update({ where:{ id:armyId }, data:{ status:'RETURNING', targetX:null, targetY:null, arrivalAt:null } });
  }
}
