import { Injectable, OnModuleInit } from '@nestjs/common';
import { InjectQueue } from '@nestjs/bull';
import { Queue } from 'bullmq';

@Injectable()
export class TickScheduler implements OnModuleInit {
  constructor(@InjectQueue('game') private q: Queue) {}
  async onModuleInit(){
    await this.q.add('tick30s', {}, { repeat: { every: 30_000 } });
  }
}
