import 'dotenv/config';
import { NestFactory } from '@nestjs/core';
import { WorkersModule } from './workers.module';
async function bootstrap(){
  await NestFactory.createApplicationContext(WorkersModule);
  console.log('Workers started');
}
bootstrap();
