import { Module } from '@nestjs/common';
import { BullModule } from '@nestjs/bull';
import { PrismaModule } from './common/prisma/prisma.module';
import { TickScheduler } from './workers/tick.scheduler';
import { TickProcessor } from './workers/tick.processor';
import Redis from 'ioredis';

@Module({
  imports: [
    PrismaModule,
    BullModule.forRoot({ connection: { url: process.env.REDIS_URL ?? 'redis://localhost:6379' } }),
    BullModule.registerQueue({ name: 'game' }),
  ],
  providers: [
    { provide: 'REDIS', useFactory: () => new Redis(process.env.REDIS_URL ?? 'redis://localhost:6379') },
    TickScheduler,
    TickProcessor,
  ],
})
export class WorkersModule {}
