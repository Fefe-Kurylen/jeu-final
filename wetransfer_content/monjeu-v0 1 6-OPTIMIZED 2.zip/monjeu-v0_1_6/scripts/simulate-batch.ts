import { execSync } from 'child_process';

const tests: Array<[string,number,string,number,string]> = [
  // baseline tiers same type (Rome infantry)
  ['ROM_INF_MILICIEN',100,'ROM_INF_TRIARII',100,'FIELD'],
  ['ROM_INF_TRIARII',100,'ROM_INF_LEGIONNAIRE',100,'FIELD'],
  ['ROM_INF_MILICIEN',200,'ROM_INF_TRIARII',100,'FIELD'],
  ['ROM_INF_TRIARII',150,'ROM_INF_LEGIONNAIRE',100,'FIELD'],
  // cross-faction example requested earlier-ish
  ['ROM_INF_TRIARII',100,'HUN_CAV_ELITE',100,'FIELD'],
];

for (const [a,ac,d,dc,mode] of tests){
  const cmd = `npx ts-node scripts/simulate.ts ${a} ${ac} ${d} ${dc} ${mode}`;
  const out = execSync(cmd, { stdio: 'pipe' }).toString('utf-8');
  const j = JSON.parse(out);
  console.log(`${a}(${ac}) vs ${d}(${dc}) [${mode}] -> winner=${j.winner} remA=${j.attackerRemaining} remD=${j.defenderRemaining}`);
}
