import { loadUnitsFromJson } from '../libs/game-data/src/loader';

const file = process.argv[2] ?? 'data/units.json';
const units = loadUnitsFromJson(file);

let ok = true;
for (const [k,u] of Object.entries(units)) {
  const s = u.stats as any;
  for (const stat of ['attack','defense','endurance','speed','transport']) {
    if (typeof s[stat] !== 'number') { console.error(`Unit ${k} missing stat ${stat}`); ok=false; }
    if (s[stat] < 0) { console.error(`Unit ${k} stat ${stat} < 0`); ok=false; }
  }
  if (s.speed > 100) { console.warn(`Unit ${k} speed > 100 (${s.speed})`); }
  if (s.attack > 125 || s.defense > 125 || s.endurance > 125) { console.warn(`Unit ${k} core stat > 125`); }
  if (s.transport > 100) { console.warn(`Unit ${k} transport > 100 (${s.transport})`); }
}
if (!ok) process.exit(1);
console.log(`OK: ${Object.keys(units).length} units validated`);
