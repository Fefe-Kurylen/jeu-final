import { simulateBattle } from '../libs/combat/src/engine';
import { UnitDef, ArmySnapshot, BattleContext } from '../libs/combat/src/types';
import { loadUnitsFromJson, loadFactionBonusesFromJson } from '../libs/game-data/src/loader';

class JsonRegistry {
  constructor(private units: Record<string, UnitDef>) {}
  getUnit(unitKey: string): UnitDef {
    const u = this.units[unitKey];
    if (!u) throw new Error(`Unknown unitKey: ${unitKey}`);
    return u;
  }
}

function usage() {
  console.log('Usage: ts-node scripts/simulate.ts <attackerUnitKey> <attackerCount> <defenderUnitKey> <defenderCount> [mode]');
  console.log('mode: FIELD | CITY_ATTACK | CITY_DEFENSE | RAID (default FIELD)');
}

async function main() {
  const [aKey,aCountStr,dKey,dCountStr,modeStr] = process.argv.slice(2);
  if (!aKey || !aCountStr || !dKey || !dCountStr) { usage(); process.exit(1); }

  const units = loadUnitsFromJson('data/units.json');
  const factions = loadFactionBonusesFromJson('data/factions.json');
  const registry = new JsonRegistry(units as any);

  const a = units[aKey] as any;
  const d = units[dKey] as any;

  const attacker: ArmySnapshot = {
    armyId: 'A1',
    playerId: 'P1',
    faction: (a.faction ?? 'ROME'),
    stacks: [{ unitKey: aKey, tier: a.tier, count: parseInt(aCountStr,10) }]
  } as any;

  const defender: ArmySnapshot = {
    armyId: 'D1',
    playerId: 'P2',
    faction: (d.faction ?? 'ROME'),
    stacks: [{ unitKey: dKey, tier: d.tier, count: parseInt(dCountStr,10) }]
  } as any;

  const mode = (modeStr ?? 'FIELD') as any;

  const ctx: BattleContext = {
    mode,
    isSiegeState: mode === 'CITY_ATTACK' || mode === 'CITY_DEFENSE',
    defenderInCity: mode !== 'FIELD',
    attackerInCity: mode === 'CITY_ATTACK',
    attackerFactionBonus: factions[attacker.faction],
    defenderFactionBonus: factions[defender.faction],
  };

  const result = simulateBattle(registry as any, attacker, defender, ctx);

  const remA = result.attacker.remaining.reduce((s,x)=>s+x.count,0);
  const remD = result.defender.remaining.reduce((s,x)=>s+x.count,0);

  console.log(JSON.stringify({
    winner: result.winner,
    rounds: result.rounds,
    attackerRemaining: remA,
    defenderRemaining: remD,
    attackerKilled: result.attacker.killed,
    defenderKilled: result.defender.killed,
    attackerWounded: result.attacker.wounded,
    defenderWounded: result.defender.wounded
  }, null, 2));
}

main().catch(e=>{ console.error(e); process.exit(1); });
