// MonJeu v0.6 - Frontend JavaScript
const API = '';
let token = localStorage.getItem('token');
let player = null;
let currentCity = null;
let cities = [];
let armies = [];
let mapX = 0, mapY = 0;

// Building icons mapping
const BUILDING_ICONS = {
  MAIN_HALL: '🏛️', BARRACKS: '⚔️', STABLE: '🐎', WORKSHOP: '⚙️',
  FARM: '🌾', LUMBER: '🪵', QUARRY: '🪨', IRON_MINE: '⛏️',
  WAREHOUSE: '📦', SILO: '🏺', MARKET: '🏪', ACADEMY: '📚',
  FORGE: '🔨', WALL: '🏰', MOAT: '💧', HEALING_TENT: '⛺',
  RALLY_POINT: '🚩', HIDEOUT: '🕳️'
};

const UNIT_ICONS = {
  INFANTRY: '🗡️', ARCHER: '🏹', CAVALRY: '🐴', SIEGE: '💣'
};

const TIER_COLORS = {
  base: '#aaa', intermediate: '#4682B4', elite: '#da70d6', siege: '#ffa500'
};

// ========== AUTH ==========
function showRegister() {
  document.getElementById('login-form').style.display = 'none';
  document.getElementById('register-form').style.display = 'block';
}

function showLogin() {
  document.getElementById('register-form').style.display = 'none';
  document.getElementById('login-form').style.display = 'block';
}

async function login() {
  const email = document.getElementById('login-email').value;
  const password = document.getElementById('login-password').value;
  
  try {
    const res = await fetch(`${API}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    const data = await res.json();
    
    if (res.ok) {
      token = data.token;
      localStorage.setItem('token', token);
      showGame();
    } else {
      showAuthError(data.error || 'Erreur de connexion');
    }
  } catch (e) {
    showAuthError('Erreur de connexion au serveur');
  }
}

async function register() {
  const email = document.getElementById('reg-email').value;
  const name = document.getElementById('reg-name').value;
  const password = document.getElementById('reg-password').value;
  const faction = document.getElementById('reg-faction').value;
  
  if (!faction) {
    showAuthError('Choisissez une faction');
    return;
  }
  
  try {
    const res = await fetch(`${API}/api/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, name, password, faction })
    });
    const data = await res.json();
    
    if (res.ok) {
      token = data.token;
      localStorage.setItem('token', token);
      showGame();
    } else {
      showAuthError(data.error || 'Erreur d\'inscription');
    }
  } catch (e) {
    showAuthError('Erreur de connexion au serveur');
  }
}

function logout() {
  token = null;
  localStorage.removeItem('token');
  document.getElementById('game-screen').style.display = 'none';
  document.getElementById('auth-screen').style.display = 'flex';
}

function showAuthError(msg) {
  const el = document.getElementById('auth-error');
  el.textContent = msg;
  setTimeout(() => el.textContent = '', 5000);
}

// ========== GAME ==========
async function showGame() {
  document.getElementById('auth-screen').style.display = 'none';
  document.getElementById('game-screen').style.display = 'flex';
  await loadPlayer();
  await loadCities();
  await loadArmies();
  startRefresh();
}

async function loadPlayer() {
  const res = await fetch(`${API}/api/player/me`, { headers: { Authorization: `Bearer ${token}` } });
  if (res.ok) {
    player = await res.json();
    document.getElementById('player-name').textContent = player.name;
    document.getElementById('player-faction').textContent = player.faction;
    document.getElementById('player-pop').textContent = player.population || 0;
    document.getElementById('res-gold').textContent = formatNum(player.gold || 0);
  }
}

async function loadCities() {
  const res = await fetch(`${API}/api/cities`, { headers: { Authorization: `Bearer ${token}` } });
  if (res.ok) {
    cities = await res.json();
    if (cities.length > 0) {
      currentCity = cities[0];
      updateCitySelector();
      renderCity();
    }
  }
}

async function loadArmies() {
  const res = await fetch(`${API}/api/armies`, { headers: { Authorization: `Bearer ${token}` } });
  if (res.ok) {
    armies = await res.json();
  }
}

function updateCitySelector() {
  const select = document.getElementById('city-select');
  select.innerHTML = cities.map(c => 
    `<option value="${c.id}" ${c.id === currentCity?.id ? 'selected' : ''}>${c.name} ${c.isCapital ? '👑' : ''}</option>`
  ).join('');
}

function selectCity(id) {
  currentCity = cities.find(c => c.id === id);
  renderCity();
}

function renderCity() {
  if (!currentCity) return;
  
  // Update resources header
  document.getElementById('res-wood').textContent = formatNum(currentCity.wood);
  document.getElementById('res-stone').textContent = formatNum(currentCity.stone);
  document.getElementById('res-iron').textContent = formatNum(currentCity.iron);
  document.getElementById('res-food').textContent = formatNum(currentCity.food);
  
  // Wall HP
  const wallPct = (currentCity.wallHp / currentCity.wallMaxHp) * 100;
  const wallFill = document.getElementById('wall-fill');
  if (wallFill) wallFill.style.width = `${wallPct}%`;
  document.getElementById('wall-hp').textContent = `${Math.floor(currentCity.wallHp)}/${currentCity.wallMaxHp}`;
  
  // Calculate production
  let woodProd = 5, stoneProd = 5, ironProd = 5, foodProd = 10;
  if (currentCity.buildings) {
    currentCity.buildings.forEach(b => {
      if (b.key === 'LUMBER') woodProd += b.level * 30;
      if (b.key === 'QUARRY') stoneProd += b.level * 30;
      if (b.key === 'IRON_MINE') ironProd += b.level * 30;
      if (b.key === 'FARM') foodProd += b.level * 40;
    });
  }
  document.getElementById('prod-wood').textContent = `+${formatNum(woodProd)}`;
  document.getElementById('prod-stone').textContent = `+${formatNum(stoneProd)}`;
  document.getElementById('prod-iron').textContent = `+${formatNum(ironProd)}`;
  document.getElementById('prod-food').textContent = `+${formatNum(foodProd)}`;
  
  // Render 2.5D city canvas
  renderCityCanvas();
  
  // Render queues
  renderBuildQueue();
  renderRecruitQueue();
  renderMovingArmies();
}

// ========== CITY CANVAS 2.5D CIRCULAR ==========
let cityCanvas, cityCtx;
let cityHoveredSlot = null;
let citySlots = [];
let currentCityView = 'city'; // 'city' ou 'fields'

// Définition des 20 slots en disposition circulaire (style Travian)
// Centre = Main Hall, puis anneaux concentriques
const CITY_LAYOUT = {
  // Anneau central (Main Hall) - slot 0
  center: { slot: 0, key: 'MAIN_HALL', fixed: true },
  
  // Anneau intérieur (6 slots) - slots 1-6
  innerRing: [
    { slot: 1, angle: 0 },
    { slot: 2, angle: 60 },
    { slot: 3, angle: 120 },
    { slot: 4, angle: 180 },
    { slot: 5, angle: 240 },
    { slot: 6, angle: 300 }
  ],
  
  // Anneau extérieur (13 slots) - slots 7-19
  outerRing: [
    { slot: 7, angle: 0 },
    { slot: 8, angle: 27.7 },
    { slot: 9, angle: 55.4 },
    { slot: 10, angle: 83.1 },
    { slot: 11, angle: 110.8 },
    { slot: 12, angle: 138.5 },
    { slot: 13, angle: 166.2 },
    { slot: 14, angle: 193.8 },
    { slot: 15, angle: 221.5 },
    { slot: 16, angle: 249.2 },
    { slot: 17, angle: 276.9 },
    { slot: 18, angle: 304.6 },
    { slot: 19, angle: 332.3 }
  ]
};

// Layout des champs de ressources (vue séparée) - 18 emplacements typique Travian
const FIELDS_LAYOUT = {
  // 4 types de ressources × plusieurs emplacements
  fields: [
    // Bois (forêt) - 4 emplacements
    { slot: 1, type: 'LUMBER', angle: 20, ring: 1 },
    { slot: 2, type: 'LUMBER', angle: 70, ring: 2 },
    { slot: 3, type: 'LUMBER', angle: 340, ring: 1 },
    { slot: 4, type: 'LUMBER', angle: 290, ring: 2 },
    
    // Pierre (carrière) - 4 emplacements
    { slot: 5, type: 'QUARRY', angle: 110, ring: 1 },
    { slot: 6, type: 'QUARRY', angle: 160, ring: 2 },
    { slot: 7, type: 'QUARRY', angle: 200, ring: 1 },
    { slot: 8, type: 'QUARRY', angle: 250, ring: 2 },
    
    // Fer (mine) - 4 emplacements
    { slot: 9, type: 'IRON_MINE', angle: 45, ring: 2 },
    { slot: 10, type: 'IRON_MINE', angle: 135, ring: 1 },
    { slot: 11, type: 'IRON_MINE', angle: 225, ring: 2 },
    { slot: 12, type: 'IRON_MINE', angle: 315, ring: 1 },
    
    // Nourriture (ferme) - 6 emplacements
    { slot: 13, type: 'FARM', angle: 0, ring: 1 },
    { slot: 14, type: 'FARM', angle: 60, ring: 1 },
    { slot: 15, type: 'FARM', angle: 120, ring: 1 },
    { slot: 16, type: 'FARM', angle: 180, ring: 1 },
    { slot: 17, type: 'FARM', angle: 240, ring: 1 },
    { slot: 18, type: 'FARM', angle: 300, ring: 1 }
  ]
};

function initCityCanvas() {
  cityCanvas = document.getElementById('city-canvas');
  if (!cityCanvas) return;
  
  cityCtx = cityCanvas.getContext('2d');
  
  // Resize to container
  const container = cityCanvas.parentElement;
  cityCanvas.width = container.clientWidth;
  cityCanvas.height = container.clientHeight;
  
  // Events
  cityCanvas.addEventListener('mousemove', onCityMouseMove);
  cityCanvas.addEventListener('click', onCityClick);
  cityCanvas.addEventListener('mouseleave', () => {
    cityHoveredSlot = null;
    renderCityCanvas();
    hideCityTooltip();
  });
  
  // Calculate slot positions
  calculateCitySlots();
}

function calculateCitySlots() {
  if (!cityCanvas) return;
  
  const w = cityCanvas.width;
  const h = cityCanvas.height;
  const centerX = w / 2;
  const centerY = h / 2 + 20;
  
  const innerRadius = Math.min(w, h) * 0.15;
  const outerRadius = Math.min(w, h) * 0.28;
  const slotSize = Math.min(w, h) * 0.07;
  
  citySlots = [];
  
  // Centre (Main Hall) - slot 0
  citySlots.push({
    slot: 0,
    x: centerX,
    y: centerY,
    size: slotSize * 1.5,
    fixed: true,
    fixedKey: 'MAIN_HALL'
  });
  
  // Anneau intérieur (6 slots) - slots 1-6
  CITY_LAYOUT.innerRing.forEach(s => {
    const rad = (s.angle - 90) * Math.PI / 180;
    citySlots.push({
      slot: s.slot,
      x: centerX + Math.cos(rad) * innerRadius,
      y: centerY + Math.sin(rad) * innerRadius * 0.55, // Écrasement pour effet 2.5D
      size: slotSize,
      ring: 'inner'
    });
  });
  
  // Anneau extérieur (13 slots) - slots 7-19
  CITY_LAYOUT.outerRing.forEach(s => {
    const rad = (s.angle - 90) * Math.PI / 180;
    citySlots.push({
      slot: s.slot,
      x: centerX + Math.cos(rad) * outerRadius,
      y: centerY + Math.sin(rad) * outerRadius * 0.55,
      size: slotSize * 0.9,
      ring: 'outer'
    });
  });
}

function calculateFieldSlots() {
  if (!cityCanvas) return;
  
  const w = cityCanvas.width;
  const h = cityCanvas.height;
  const centerX = w / 2;
  const centerY = h / 2 + 30;
  
  const ring1Radius = Math.min(w, h) * 0.22;
  const ring2Radius = Math.min(w, h) * 0.35;
  const slotSize = Math.min(w, h) * 0.08;
  
  citySlots = [];
  
  // Centre = vue ville (bouton retour)
  citySlots.push({
    slot: -1, // Slot spécial pour retour ville
    x: centerX,
    y: centerY,
    size: slotSize * 1.8,
    isVillageCenter: true
  });
  
  // Champs de ressources en anneaux
  FIELDS_LAYOUT.fields.forEach(f => {
    const radius = f.ring === 1 ? ring1Radius : ring2Radius;
    const rad = (f.angle - 90) * Math.PI / 180;
    
    citySlots.push({
      slot: f.slot,
      x: centerX + Math.cos(rad) * radius,
      y: centerY + Math.sin(rad) * radius * 0.5, // Écrasement 2.5D
      size: slotSize,
      isField: true,
      fieldType: f.type,
      ring: f.ring
    });
  });
}

function renderCityCanvas() {
  if (!cityCtx || !cityCanvas) {
    initCityCanvas();
    if (!cityCtx) return;
  }
  
  // Recalculer les slots selon la vue
  if (currentCityView === 'city') {
    calculateCitySlots();
    renderCityView();
  } else {
    calculateFieldSlots();
    renderFieldsView();
  }
  
  // Mettre à jour l'indicateur
  updateViewIndicator();
}

function updateViewIndicator() {
  const indicator = document.getElementById('view-indicator');
  if (!indicator) return;
  
  if (currentCityView === 'city') {
    indicator.innerHTML = `
      <span class="view-label">🏰 Vue Ville</span>
      <span class="view-slots">20 emplacements</span>
    `;
  } else {
    indicator.innerHTML = `
      <span class="view-label">🌾 Vue Champs</span>
      <span class="view-slots">18 champs de ressources</span>
    `;
  }
}

function switchCityView(view) {
  currentCityView = view;
  
  // Update button states
  document.getElementById('btn-view-city').classList.toggle('active', view === 'city');
  document.getElementById('btn-view-fields').classList.toggle('active', view === 'fields');
  
  // Re-render
  renderCityCanvas();
}

function renderCityView() {
  const w = cityCanvas.width;
  const h = cityCanvas.height;
  const centerX = w / 2;
  const centerY = h / 2 + 20;
  
  // Clear
  cityCtx.clearRect(0, 0, w, h);
  
  // ========== SKY ==========
  const skyGrad = cityCtx.createLinearGradient(0, 0, 0, h * 0.5);
  skyGrad.addColorStop(0, '#4a90c2');
  skyGrad.addColorStop(0.5, '#7bb8e0');
  skyGrad.addColorStop(1, '#a8d4f0');
  cityCtx.fillStyle = skyGrad;
  cityCtx.fillRect(0, 0, w, h * 0.5);
  
  // Sun with rays
  drawSun(w - 100, 70, 35);
  
  // Clouds
  drawCloud(cityCtx, 80, 45, 45);
  drawCloud(cityCtx, 250, 75, 35);
  drawCloud(cityCtx, w - 250, 55, 40);
  drawCloud(cityCtx, w / 2, 40, 50);
  
  // ========== DISTANT MOUNTAINS ==========
  drawMountains(w, h);
  
  // ========== PLAINS / GROUND ==========
  const groundY = h * 0.45;
  
  // Far grass (lighter)
  const farGrassGrad = cityCtx.createLinearGradient(0, groundY, 0, h);
  farGrassGrad.addColorStop(0, '#6a9a4a');
  farGrassGrad.addColorStop(0.3, '#5a8a3a');
  farGrassGrad.addColorStop(0.7, '#4a7a2a');
  farGrassGrad.addColorStop(1, '#3a6a1a');
  cityCtx.fillStyle = farGrassGrad;
  cityCtx.fillRect(0, groundY, w, h - groundY);
  
  // ========== DISTANT TREES (forest line) ==========
  drawForestLine(w, groundY);
  
  // ========== RIVER ==========
  drawRiver(w, h, groundY);
  
  // ========== SCATTERED TREES ==========
  drawScatteredTrees(w, h, groundY, centerX, centerY);
  
  // ========== FIELDS / CROPS around city ==========
  drawCropFields(w, h, centerX, centerY);
  
  // ========== PATHS leading to city ==========
  drawPaths(w, h, centerX, centerY);
  
  // ========== CITY CIRCLE ==========
  const cityRadius = Math.min(w, h) * 0.32;
  
  // Outer wall shadow
  cityCtx.fillStyle = 'rgba(0,0,0,0.35)';
  cityCtx.beginPath();
  cityCtx.ellipse(centerX + 8, centerY + 12, cityRadius + 15, (cityRadius + 15) * 0.5, 0, 0, Math.PI * 2);
  cityCtx.fill();
  
  // Moat (water around city)
  const moatGrad = cityCtx.createRadialGradient(centerX, centerY, cityRadius - 5, centerX, centerY, cityRadius + 20);
  moatGrad.addColorStop(0, '#4a8ab0');
  moatGrad.addColorStop(0.5, '#3a7aa0');
  moatGrad.addColorStop(1, '#5a9ac0');
  cityCtx.fillStyle = moatGrad;
  cityCtx.beginPath();
  cityCtx.ellipse(centerX, centerY, cityRadius + 15, (cityRadius + 15) * 0.5, 0, 0, Math.PI * 2);
  cityCtx.fill();
  
  // City ground (dirt/cobblestone)
  const dirtGrad = cityCtx.createRadialGradient(centerX, centerY - 20, 0, centerX, centerY, cityRadius);
  dirtGrad.addColorStop(0, '#d4b896');
  dirtGrad.addColorStop(0.4, '#c4a876');
  dirtGrad.addColorStop(0.8, '#a48856');
  dirtGrad.addColorStop(1, '#846838');
  cityCtx.fillStyle = dirtGrad;
  cityCtx.beginPath();
  cityCtx.ellipse(centerX, centerY, cityRadius - 5, (cityRadius - 5) * 0.5, 0, 0, Math.PI * 2);
  cityCtx.fill();
  
  // Stone wall ring
  drawCityWall(centerX, centerY, cityRadius);
  
  // Draw roads inside city
  drawCityRoads(centerX, centerY);
  
  // ========== RESOURCE FIELDS (4 coins) ==========
  citySlots.filter(s => s.isField).forEach(slot => {
    drawResourceField(slot);
  });
  
  // ========== BUILDINGS ==========
  // Sort by Y for proper layering (back to front)
  const sortedSlots = citySlots.filter(s => !s.isField).sort((a, b) => a.y - b.y);
  
  sortedSlots.forEach(slot => {
    const building = getBuildingAtSlot(slot.slot);
    const isHovered = cityHoveredSlot === slot.slot;
    const isBuilding = currentCity?.buildQueue?.some(q => q.slot === slot.slot && q.status === 'RUNNING');
    
    drawBuildingSlot(slot, building, isHovered, isBuilding);
  });
  
  // ========== DECORATIVE ELEMENTS ==========
  drawDecorations(w, h, centerX, centerY);
}

function drawSun(x, y, radius) {
  // Sun glow
  const glowGrad = cityCtx.createRadialGradient(x, y, 0, x, y, radius * 2.5);
  glowGrad.addColorStop(0, 'rgba(255,248,200,0.8)');
  glowGrad.addColorStop(0.5, 'rgba(255,220,100,0.3)');
  glowGrad.addColorStop(1, 'rgba(255,200,50,0)');
  cityCtx.fillStyle = glowGrad;
  cityCtx.beginPath();
  cityCtx.arc(x, y, radius * 2.5, 0, Math.PI * 2);
  cityCtx.fill();
  
  // Sun rays
  cityCtx.strokeStyle = 'rgba(255,240,150,0.4)';
  cityCtx.lineWidth = 2;
  for (let i = 0; i < 12; i++) {
    const angle = (i * 30) * Math.PI / 180;
    cityCtx.beginPath();
    cityCtx.moveTo(x + Math.cos(angle) * radius * 1.3, y + Math.sin(angle) * radius * 1.3);
    cityCtx.lineTo(x + Math.cos(angle) * radius * 2, y + Math.sin(angle) * radius * 2);
    cityCtx.stroke();
  }
  
  // Sun disc
  cityCtx.fillStyle = '#fff8dc';
  cityCtx.shadowColor = '#ffd700';
  cityCtx.shadowBlur = 30;
  cityCtx.beginPath();
  cityCtx.arc(x, y, radius, 0, Math.PI * 2);
  cityCtx.fill();
  cityCtx.shadowBlur = 0;
}

function drawMountains(w, h) {
  const mountainY = h * 0.45;
  
  // Far mountains (blue/purple)
  cityCtx.fillStyle = '#8090a8';
  cityCtx.beginPath();
  cityCtx.moveTo(0, mountainY);
  cityCtx.lineTo(w * 0.15, mountainY - 60);
  cityCtx.lineTo(w * 0.25, mountainY - 30);
  cityCtx.lineTo(w * 0.4, mountainY - 80);
  cityCtx.lineTo(w * 0.5, mountainY - 40);
  cityCtx.lineTo(w * 0.65, mountainY - 90);
  cityCtx.lineTo(w * 0.8, mountainY - 50);
  cityCtx.lineTo(w * 0.9, mountainY - 70);
  cityCtx.lineTo(w, mountainY - 35);
  cityCtx.lineTo(w, mountainY);
  cityCtx.closePath();
  cityCtx.fill();
  
  // Snow caps
  cityCtx.fillStyle = '#e8e8f0';
  cityCtx.beginPath();
  cityCtx.moveTo(w * 0.38, mountainY - 75);
  cityCtx.lineTo(w * 0.4, mountainY - 80);
  cityCtx.lineTo(w * 0.42, mountainY - 72);
  cityCtx.closePath();
  cityCtx.fill();
  
  cityCtx.beginPath();
  cityCtx.moveTo(w * 0.63, mountainY - 85);
  cityCtx.lineTo(w * 0.65, mountainY - 90);
  cityCtx.lineTo(w * 0.67, mountainY - 82);
  cityCtx.closePath();
  cityCtx.fill();
}

function drawForestLine(w, groundY) {
  cityCtx.fillStyle = '#3a5a2a';
  
  for (let x = 0; x < w; x += 25) {
    const treeH = 15 + Math.sin(x * 0.1) * 8;
    const treeY = groundY + 5 + Math.sin(x * 0.05) * 3;
    
    cityCtx.beginPath();
    cityCtx.moveTo(x, treeY);
    cityCtx.lineTo(x + 12, treeY);
    cityCtx.lineTo(x + 6, treeY - treeH);
    cityCtx.closePath();
    cityCtx.fill();
  }
}

function drawRiver(w, h, groundY) {
  cityCtx.strokeStyle = '#5090c0';
  cityCtx.lineWidth = 20;
  cityCtx.lineCap = 'round';
  
  cityCtx.beginPath();
  cityCtx.moveTo(-20, groundY + 30);
  cityCtx.bezierCurveTo(w * 0.2, groundY + 60, w * 0.15, h * 0.65, w * 0.08, h + 20);
  cityCtx.stroke();
  
  // River highlight
  cityCtx.strokeStyle = 'rgba(150,200,230,0.5)';
  cityCtx.lineWidth = 8;
  cityCtx.beginPath();
  cityCtx.moveTo(-15, groundY + 28);
  cityCtx.bezierCurveTo(w * 0.18, groundY + 55, w * 0.13, h * 0.63, w * 0.06, h + 15);
  cityCtx.stroke();
}

function drawScatteredTrees(w, h, groundY, centerX, centerY) {
  const trees = [
    { x: 60, y: groundY + 80, size: 35 },
    { x: 120, y: groundY + 120, size: 40 },
    { x: w - 80, y: groundY + 90, size: 38 },
    { x: w - 150, y: groundY + 140, size: 42 },
    { x: w - 60, y: h - 100, size: 35 },
    { x: 80, y: h - 80, size: 30 },
    { x: w / 2 - 200, y: groundY + 60, size: 32 },
    { x: w / 2 + 200, y: groundY + 70, size: 36 }
  ];
  
  trees.forEach(tree => {
    // Skip if too close to city
    const dx = tree.x - centerX;
    const dy = tree.y - centerY;
    if (Math.sqrt(dx*dx + dy*dy) < 200) return;
    
    drawTree(tree.x, tree.y, tree.size);
  });
}

function drawTree(x, y, size) {
  // Shadow
  cityCtx.fillStyle = 'rgba(0,0,0,0.2)';
  cityCtx.beginPath();
  cityCtx.ellipse(x + 3, y + 5, size * 0.4, size * 0.15, 0, 0, Math.PI * 2);
  cityCtx.fill();
  
  // Trunk
  cityCtx.fillStyle = '#5a4030';
  cityCtx.fillRect(x - size * 0.08, y - size * 0.3, size * 0.16, size * 0.35);
  
  // Foliage layers
  const colors = ['#2a5a1a', '#3a6a2a', '#4a7a3a'];
  
  for (let i = 0; i < 3; i++) {
    cityCtx.fillStyle = colors[i];
    cityCtx.beginPath();
    cityCtx.moveTo(x, y - size * (0.6 + i * 0.25));
    cityCtx.lineTo(x - size * (0.4 - i * 0.08), y - size * (0.2 + i * 0.15));
    cityCtx.lineTo(x + size * (0.4 - i * 0.08), y - size * (0.2 + i * 0.15));
    cityCtx.closePath();
    cityCtx.fill();
  }
}

function drawCropFields(w, h, centerX, centerY) {
  // Wheat fields (golden rectangles around city)
  const fields = [
    { x: 50, y: h * 0.55, w: 80, h: 50, color: '#c4a030' },
    { x: w - 130, y: h * 0.58, w: 90, h: 45, color: '#d4b040' },
    { x: 30, y: h - 120, w: 70, h: 40, color: '#b49020' },
    { x: w - 100, y: h - 110, w: 60, h: 35, color: '#c4a030' }
  ];
  
  fields.forEach(field => {
    // Field base
    cityCtx.fillStyle = field.color;
    cityCtx.beginPath();
    cityCtx.moveTo(field.x, field.y + field.h * 0.3);
    cityCtx.lineTo(field.x + field.w * 0.1, field.y);
    cityCtx.lineTo(field.x + field.w * 0.9, field.y);
    cityCtx.lineTo(field.x + field.w, field.y + field.h * 0.3);
    cityCtx.lineTo(field.x + field.w, field.y + field.h);
    cityCtx.lineTo(field.x, field.y + field.h);
    cityCtx.closePath();
    cityCtx.fill();
    
    // Crop lines
    cityCtx.strokeStyle = 'rgba(0,0,0,0.15)';
    cityCtx.lineWidth = 1;
    for (let i = 0; i < 5; i++) {
      const lineY = field.y + field.h * 0.3 + (field.h * 0.7 / 5) * i;
      cityCtx.beginPath();
      cityCtx.moveTo(field.x + 5, lineY);
      cityCtx.lineTo(field.x + field.w - 5, lineY);
      cityCtx.stroke();
    }
  });
}

function drawPaths(w, h, centerX, centerY) {
  cityCtx.strokeStyle = '#a08050';
  cityCtx.lineWidth = 12;
  cityCtx.lineCap = 'round';
  
  // Main road from bottom
  cityCtx.beginPath();
  cityCtx.moveTo(w / 2 + 30, h + 10);
  cityCtx.quadraticCurveTo(w / 2, h * 0.8, centerX, centerY + 100);
  cityCtx.stroke();
  
  // Road from right
  cityCtx.beginPath();
  cityCtx.moveTo(w + 10, h * 0.6);
  cityCtx.quadraticCurveTo(w * 0.8, h * 0.55, centerX + 120, centerY + 30);
  cityCtx.stroke();
  
  // Road highlight
  cityCtx.strokeStyle = '#c0a070';
  cityCtx.lineWidth = 4;
  
  cityCtx.beginPath();
  cityCtx.moveTo(w / 2 + 32, h + 10);
  cityCtx.quadraticCurveTo(w / 2 + 2, h * 0.8, centerX + 2, centerY + 100);
  cityCtx.stroke();
}

function drawCityWall(centerX, centerY, radius) {
  const wallRadius = radius - 3;
  
  // Stone wall base
  cityCtx.strokeStyle = '#5a5a5a';
  cityCtx.lineWidth = 18;
  cityCtx.beginPath();
  cityCtx.ellipse(centerX, centerY, wallRadius, wallRadius * 0.5, 0, 0, Math.PI * 2);
  cityCtx.stroke();
  
  // Wall detail (bricks pattern)
  cityCtx.strokeStyle = '#4a4a4a';
  cityCtx.lineWidth = 2;
  for (let angle = 0; angle < 360; angle += 15) {
    const rad = angle * Math.PI / 180;
    const x1 = centerX + Math.cos(rad) * (wallRadius - 8);
    const y1 = centerY + Math.sin(rad) * (wallRadius - 8) * 0.5;
    const x2 = centerX + Math.cos(rad) * (wallRadius + 8);
    const y2 = centerY + Math.sin(rad) * (wallRadius + 8) * 0.5;
    cityCtx.beginPath();
    cityCtx.moveTo(x1, y1);
    cityCtx.lineTo(x2, y2);
    cityCtx.stroke();
  }
  
  // Wall top highlight
  cityCtx.strokeStyle = '#8a8a8a';
  cityCtx.lineWidth = 4;
  cityCtx.beginPath();
  cityCtx.ellipse(centerX, centerY, wallRadius, wallRadius * 0.5, 0, Math.PI, Math.PI * 2);
  cityCtx.stroke();
  
  // Towers (4 corners)
  const towerAngles = [45, 135, 225, 315];
  towerAngles.forEach(angle => {
    const rad = angle * Math.PI / 180;
    const tx = centerX + Math.cos(rad) * wallRadius;
    const ty = centerY + Math.sin(rad) * wallRadius * 0.5;
    drawTower(tx, ty, 18);
  });
  
  // Main gate (south)
  const gateX = centerX;
  const gateY = centerY + wallRadius * 0.5;
  drawGate(gateX, gateY);
}

function drawTower(x, y, size) {
  // Tower base
  cityCtx.fillStyle = '#6a6a6a';
  cityCtx.beginPath();
  cityCtx.ellipse(x, y, size, size * 0.5, 0, 0, Math.PI * 2);
  cityCtx.fill();
  
  // Tower body
  cityCtx.fillStyle = '#5a5a5a';
  cityCtx.fillRect(x - size * 0.7, y - size * 1.5, size * 1.4, size * 1.5);
  
  // Tower top
  cityCtx.fillStyle = '#7a7a7a';
  cityCtx.beginPath();
  cityCtx.ellipse(x, y - size * 1.5, size * 0.8, size * 0.4, 0, 0, Math.PI * 2);
  cityCtx.fill();
  
  // Battlements
  cityCtx.fillStyle = '#5a5a5a';
  for (let i = 0; i < 4; i++) {
    const bx = x - size * 0.6 + i * size * 0.4;
    cityCtx.fillRect(bx, y - size * 1.9, size * 0.25, size * 0.4);
  }
  
  // Flag
  cityCtx.fillStyle = '#c44';
  cityCtx.beginPath();
  cityCtx.moveTo(x, y - size * 2.2);
  cityCtx.lineTo(x + size * 0.5, y - size * 2);
  cityCtx.lineTo(x, y - size * 1.8);
  cityCtx.fill();
  
  cityCtx.strokeStyle = '#444';
  cityCtx.lineWidth = 2;
  cityCtx.beginPath();
  cityCtx.moveTo(x, y - size * 1.5);
  cityCtx.lineTo(x, y - size * 2.3);
  cityCtx.stroke();
}

function drawGate(x, y) {
  // Gate house
  cityCtx.fillStyle = '#5a5a5a';
  cityCtx.fillRect(x - 25, y - 40, 50, 45);
  
  // Gate opening (dark)
  cityCtx.fillStyle = '#1a1a1a';
  cityCtx.beginPath();
  cityCtx.moveTo(x - 15, y + 5);
  cityCtx.lineTo(x - 15, y - 20);
  cityCtx.arc(x, y - 20, 15, Math.PI, 0);
  cityCtx.lineTo(x + 15, y + 5);
  cityCtx.closePath();
  cityCtx.fill();
  
  // Gate bars
  cityCtx.strokeStyle = '#4a3020';
  cityCtx.lineWidth = 3;
  for (let i = -10; i <= 10; i += 5) {
    cityCtx.beginPath();
    cityCtx.moveTo(x + i, y - 30);
    cityCtx.lineTo(x + i, y + 5);
    cityCtx.stroke();
  }
  
  // Battlements
  cityCtx.fillStyle = '#6a6a6a';
  for (let i = 0; i < 5; i++) {
    cityCtx.fillRect(x - 23 + i * 10, y - 50, 8, 12);
  }
}

function drawDecorations(w, h, centerX, centerY) {
  // Birds in sky
  cityCtx.strokeStyle = '#333';
  cityCtx.lineWidth = 1;
  
  const birds = [
    { x: 150, y: 100 },
    { x: 180, y: 95 },
    { x: w - 200, y: 85 },
    { x: w - 230, y: 90 }
  ];
  
  birds.forEach(bird => {
    cityCtx.beginPath();
    cityCtx.moveTo(bird.x - 6, bird.y);
    cityCtx.quadraticCurveTo(bird.x - 3, bird.y - 4, bird.x, bird.y);
    cityCtx.quadraticCurveTo(bird.x + 3, bird.y - 4, bird.x + 6, bird.y);
    cityCtx.stroke();
  });
  
  // Smoke from buildings (if forge exists)
  const forgeBuilding = currentCity?.buildings?.find(b => b.key === 'FORGE');
  if (forgeBuilding) {
    const forgeSlot = citySlots.find(s => s.slot === forgeBuilding.slot);
    if (forgeSlot) {
      drawSmoke(forgeSlot.x, forgeSlot.y - 60);
    }
  }
}

function drawSmoke(x, y) {
  const time = Date.now() / 1000;
  
  for (let i = 0; i < 5; i++) {
    const offset = i * 15;
    const alpha = 0.3 - i * 0.05;
    const size = 8 + i * 4;
    const drift = Math.sin(time + i) * 5;
    
    cityCtx.fillStyle = `rgba(150,150,150,${alpha})`;
    cityCtx.beginPath();
    cityCtx.arc(x + drift, y - offset, size, 0, Math.PI * 2);
    cityCtx.fill();
  }
}

// ========== VUE CHAMPS DE RESSOURCES ==========
function renderFieldsView() {
  const w = cityCanvas.width;
  const h = cityCanvas.height;
  const centerX = w / 2;
  const centerY = h / 2 + 30;
  
  // Clear
  cityCtx.clearRect(0, 0, w, h);
  
  // ========== SKY ==========
  const skyGrad = cityCtx.createLinearGradient(0, 0, 0, h * 0.45);
  skyGrad.addColorStop(0, '#5a9ac2');
  skyGrad.addColorStop(0.5, '#7bc8e0');
  skyGrad.addColorStop(1, '#a8e4f0');
  cityCtx.fillStyle = skyGrad;
  cityCtx.fillRect(0, 0, w, h * 0.45);
  
  // Sun
  drawSun(w - 100, 70, 35);
  
  // Clouds
  drawCloud(cityCtx, 100, 55, 40);
  drawCloud(cityCtx, w - 180, 70, 45);
  
  // ========== GROUND - FARMLAND ==========
  const groundY = h * 0.42;
  
  // Background hills
  cityCtx.fillStyle = '#5a8a4a';
  cityCtx.beginPath();
  cityCtx.moveTo(0, groundY);
  cityCtx.quadraticCurveTo(w * 0.25, groundY - 30, w * 0.5, groundY);
  cityCtx.quadraticCurveTo(w * 0.75, groundY - 20, w, groundY);
  cityCtx.lineTo(w, h);
  cityCtx.lineTo(0, h);
  cityCtx.closePath();
  cityCtx.fill();
  
  // Main ground
  const groundGrad = cityCtx.createLinearGradient(0, groundY, 0, h);
  groundGrad.addColorStop(0, '#6a9a5a');
  groundGrad.addColorStop(0.3, '#5a8a4a');
  groundGrad.addColorStop(0.7, '#4a7a3a');
  groundGrad.addColorStop(1, '#3a6a2a');
  cityCtx.fillStyle = groundGrad;
  cityCtx.fillRect(0, groundY, w, h - groundY);
  
  // ========== SCATTERED TREES AROUND ==========
  const treesPos = [
    { x: 40, y: groundY + 50, size: 35 },
    { x: w - 50, y: groundY + 60, size: 38 },
    { x: 30, y: h - 60, size: 30 },
    { x: w - 40, y: h - 50, size: 32 }
  ];
  treesPos.forEach(t => drawTree(t.x, t.y, t.size));
  
  // ========== PATHS TO FIELDS ==========
  cityCtx.strokeStyle = '#8a7050';
  cityCtx.lineWidth = 10;
  cityCtx.lineCap = 'round';
  
  // Paths from center to fields
  citySlots.filter(s => s.isField).forEach(slot => {
    cityCtx.beginPath();
    cityCtx.moveTo(centerX, centerY);
    cityCtx.lineTo(slot.x, slot.y);
    cityCtx.stroke();
  });
  
  // ========== VILLAGE CENTER (click to return to city view) ==========
  const villageSlot = citySlots.find(s => s.isVillageCenter);
  if (villageSlot) {
    drawVillageCenter(villageSlot, cityHoveredSlot === -1);
  }
  
  // ========== RESOURCE FIELDS ==========
  // Sort by Y for proper layering
  const sortedFields = citySlots.filter(s => s.isField).sort((a, b) => a.y - b.y);
  
  sortedFields.forEach(slot => {
    const building = getFieldBuildingAtSlot(slot.slot, slot.fieldType);
    const isHovered = cityHoveredSlot === slot.slot;
    const isBuilding = currentCity?.buildQueue?.some(q => 
      q.buildingKey === slot.fieldType && q.status === 'RUNNING'
    );
    
    drawFieldSlot(slot, building, isHovered, isBuilding);
  });
  
  // Birds
  cityCtx.strokeStyle = '#333';
  cityCtx.lineWidth = 1;
  [[120, 80], [w - 150, 90]].forEach(([bx, by]) => {
    cityCtx.beginPath();
    cityCtx.moveTo(bx - 5, by);
    cityCtx.quadraticCurveTo(bx - 2, by - 3, bx, by);
    cityCtx.quadraticCurveTo(bx + 2, by - 3, bx + 5, by);
    cityCtx.stroke();
  });
}

function drawVillageCenter(slot, isHovered) {
  const { x, y, size } = slot;
  
  // Shadow
  cityCtx.fillStyle = 'rgba(0,0,0,0.3)';
  cityCtx.beginPath();
  cityCtx.ellipse(x + 5, y + 8, size * 0.6, size * 0.3, 0, 0, Math.PI * 2);
  cityCtx.fill();
  
  // Glow if hovered
  if (isHovered) {
    cityCtx.shadowColor = '#ffd700';
    cityCtx.shadowBlur = 25;
  }
  
  // Village base (circular wall)
  cityCtx.fillStyle = '#7a7a7a';
  cityCtx.beginPath();
  cityCtx.ellipse(x, y, size * 0.55, size * 0.3, 0, 0, Math.PI * 2);
  cityCtx.fill();
  
  // Village ground
  cityCtx.fillStyle = '#c4a060';
  cityCtx.beginPath();
  cityCtx.ellipse(x, y, size * 0.45, size * 0.25, 0, 0, Math.PI * 2);
  cityCtx.fill();
  
  cityCtx.shadowBlur = 0;
  
  // Mini buildings
  drawMapBuilding(x, y - 8, size * 0.2, '#d4a84b', '#8b6914');
  drawMapBuilding(x - size * 0.2, y + 3, size * 0.12, '#8b7355', '#5a4030');
  drawMapBuilding(x + size * 0.2, y + 3, size * 0.12, '#8b7355', '#5a4030');
  
  // Label
  cityCtx.font = 'bold 12px Cinzel, serif';
  cityCtx.textAlign = 'center';
  cityCtx.fillStyle = '#fff';
  cityCtx.shadowColor = '#000';
  cityCtx.shadowBlur = 3;
  cityCtx.fillText('🏰 Ville', x, y + size * 0.5);
  cityCtx.shadowBlur = 0;
  
  if (isHovered) {
    cityCtx.font = '10px Arial';
    cityCtx.fillStyle = '#ffd700';
    cityCtx.fillText('Cliquez pour voir la ville', x, y + size * 0.65);
  }
}

function drawFieldSlot(slot, building, isHovered, isBuilding) {
  const { x, y, size, fieldType } = slot;
  const level = building?.level || 0;
  
  // Field colors by type
  const fieldStyles = {
    FARM: { bg: '#c4a030', detail: '#a48020', icon: '🌾', name: 'Ferme' },
    LUMBER: { bg: '#4a6a3a', detail: '#3a5a2a', icon: '🌲', name: 'Bûcheron' },
    QUARRY: { bg: '#8a8a8a', detail: '#6a6a6a', icon: '⛰️', name: 'Carrière' },
    IRON_MINE: { bg: '#6a6a7a', detail: '#5a5a6a', icon: '⛏️', name: 'Mine' }
  };
  
  const style = fieldStyles[fieldType] || fieldStyles.FARM;
  
  // Shadow
  cityCtx.fillStyle = 'rgba(0,0,0,0.3)';
  cityCtx.beginPath();
  cityCtx.ellipse(x + 3, y + 5, size * 0.7, size * 0.35, 0, 0, Math.PI * 2);
  cityCtx.fill();
  
  // Hover glow
  if (isHovered) {
    cityCtx.shadowColor = '#ffd700';
    cityCtx.shadowBlur = 20;
  }
  
  // Field base
  cityCtx.fillStyle = style.bg;
  cityCtx.beginPath();
  cityCtx.ellipse(x, y, size * 0.65, size * 0.35, 0, 0, Math.PI * 2);
  cityCtx.fill();
  
  // Field detail (inner)
  cityCtx.fillStyle = style.detail;
  cityCtx.beginPath();
  cityCtx.ellipse(x, y, size * 0.5, size * 0.25, 0, 0, Math.PI * 2);
  cityCtx.fill();
  
  cityCtx.shadowBlur = 0;
  
  // Border
  cityCtx.strokeStyle = isHovered ? '#ffd700' : style.detail;
  cityCtx.lineWidth = isHovered ? 3 : 2;
  cityCtx.beginPath();
  cityCtx.ellipse(x, y, size * 0.65, size * 0.35, 0, 0, Math.PI * 2);
  cityCtx.stroke();
  
  if (level > 0) {
    // Draw field-specific elements based on type
    if (fieldType === 'FARM') {
      // Wheat rows
      cityCtx.strokeStyle = '#8a7020';
      cityCtx.lineWidth = 2;
      for (let i = -2; i <= 2; i++) {
        cityCtx.beginPath();
        cityCtx.moveTo(x - size * 0.35, y + i * 6);
        cityCtx.lineTo(x + size * 0.35, y + i * 6);
        cityCtx.stroke();
      }
    } else if (fieldType === 'LUMBER') {
      // Mini trees
      for (let i = -1; i <= 1; i++) {
        drawMiniTree(x + i * size * 0.25, y - 5, size * 0.2);
      }
    } else if (fieldType === 'QUARRY') {
      // Rock piles
      cityCtx.fillStyle = '#9a9a9a';
      cityCtx.beginPath();
      cityCtx.arc(x - size * 0.15, y, size * 0.12, 0, Math.PI * 2);
      cityCtx.arc(x + size * 0.15, y, size * 0.1, 0, Math.PI * 2);
      cityCtx.arc(x, y - size * 0.08, size * 0.08, 0, Math.PI * 2);
      cityCtx.fill();
    } else if (fieldType === 'IRON_MINE') {
      // Mine entrance
      cityCtx.fillStyle = '#2a2a2a';
      cityCtx.beginPath();
      cityCtx.arc(x, y, size * 0.15, Math.PI, 0);
      cityCtx.lineTo(x + size * 0.15, y + size * 0.1);
      cityCtx.lineTo(x - size * 0.15, y + size * 0.1);
      cityCtx.closePath();
      cityCtx.fill();
    }
  }
  
  // Icon
  cityCtx.font = `${size * 0.5}px Arial`;
  cityCtx.textAlign = 'center';
  cityCtx.textBaseline = 'middle';
  cityCtx.fillText(style.icon, x, y - size * 0.1);
  
  // Level badge
  if (level > 0) {
    const badgeX = x + size * 0.5;
    const badgeY = y - size * 0.15;
    
    cityCtx.fillStyle = 'rgba(0,0,0,0.8)';
    cityCtx.beginPath();
    cityCtx.arc(badgeX, badgeY, 14, 0, Math.PI * 2);
    cityCtx.fill();
    
    cityCtx.strokeStyle = '#ffd700';
    cityCtx.lineWidth = 2;
    cityCtx.stroke();
    
    cityCtx.fillStyle = '#ffd700';
    cityCtx.font = 'bold 12px Cinzel, serif';
    cityCtx.fillText(level, badgeX, badgeY + 1);
  } else {
    // Empty slot indicator
    cityCtx.fillStyle = 'rgba(255,255,255,0.5)';
    cityCtx.font = `bold ${size * 0.3}px Arial`;
    cityCtx.fillText('+', x, y + size * 0.15);
  }
  
  // Construction indicator
  if (isBuilding) {
    cityCtx.fillStyle = 'rgba(255,165,0,0.9)';
    cityCtx.font = '18px Arial';
    cityCtx.fillText('🔨', x, y - size * 0.4);
  }
}

function drawMiniTree(x, y, size) {
  cityCtx.fillStyle = '#3a5a2a';
  cityCtx.beginPath();
  cityCtx.moveTo(x, y - size);
  cityCtx.lineTo(x - size * 0.5, y);
  cityCtx.lineTo(x + size * 0.5, y);
  cityCtx.closePath();
  cityCtx.fill();
  
  cityCtx.fillStyle = '#5a4030';
  cityCtx.fillRect(x - size * 0.1, y, size * 0.2, size * 0.3);
}

function getFieldBuildingAtSlot(slotNum, fieldType) {
  // Les champs de ressources sont stockés différemment
  // On cherche le bâtiment de ce type avec ce numéro de slot
  return currentCity?.buildings?.find(b => 
    b.key === fieldType && b.slot === slotNum + 100 // Offset pour différencier des slots ville
  );
}


function drawCloud(ctx, x, y, size) {
  ctx.fillStyle = 'rgba(255,255,255,0.8)';
  ctx.beginPath();
  ctx.arc(x, y, size * 0.5, 0, Math.PI * 2);
  ctx.arc(x + size * 0.4, y - size * 0.1, size * 0.4, 0, Math.PI * 2);
  ctx.arc(x + size * 0.8, y, size * 0.5, 0, Math.PI * 2);
  ctx.arc(x + size * 0.4, y + size * 0.2, size * 0.35, 0, Math.PI * 2);
  ctx.fill();
}

function drawCityRoads(centerX, centerY) {
  cityCtx.strokeStyle = '#8a7050';
  cityCtx.lineWidth = 8;
  cityCtx.lineCap = 'round';
  
  // Roads from center to inner ring
  citySlots.filter(s => s.ring === 'inner').forEach(slot => {
    cityCtx.beginPath();
    cityCtx.moveTo(centerX, centerY);
    cityCtx.lineTo(slot.x, slot.y);
    cityCtx.stroke();
  });
  
  // Road highlight
  cityCtx.strokeStyle = '#a09070';
  cityCtx.lineWidth = 3;
  citySlots.filter(s => s.ring === 'inner').forEach(slot => {
    cityCtx.beginPath();
    cityCtx.moveTo(centerX, centerY);
    cityCtx.lineTo(slot.x, slot.y);
    cityCtx.stroke();
  });
}

function drawResourceField(slot) {
  const { x, y, size, fieldType } = slot;
  const building = getBuildingAtSlot(slot.slot);
  const level = building?.level || 0;
  const isHovered = cityHoveredSlot === slot.slot;
  
  // Field colors by type
  const fieldColors = {
    FARM: { bg: '#7a9a40', detail: '#5a7a20', icon: '🌾' },
    LUMBER: { bg: '#4a6a3a', detail: '#3a5a2a', icon: '🌲' },
    QUARRY: { bg: '#7a7a7a', detail: '#5a5a5a', icon: '⛰️' },
    IRON_MINE: { bg: '#5a5a6a', detail: '#4a4a5a', icon: '⛏️' }
  };
  
  const colors = fieldColors[fieldType] || fieldColors.FARM;
  
  // Shadow
  cityCtx.fillStyle = 'rgba(0,0,0,0.3)';
  cityCtx.beginPath();
  cityCtx.ellipse(x + 3, y + 5, size, size * 0.5, 0, 0, Math.PI * 2);
  cityCtx.fill();
  
  // Field base
  cityCtx.fillStyle = colors.bg;
  if (isHovered) {
    cityCtx.shadowColor = '#ffd700';
    cityCtx.shadowBlur = 20;
  }
  cityCtx.beginPath();
  cityCtx.ellipse(x, y, size, size * 0.5, 0, 0, Math.PI * 2);
  cityCtx.fill();
  cityCtx.shadowBlur = 0;
  
  // Field border
  cityCtx.strokeStyle = isHovered ? '#ffd700' : colors.detail;
  cityCtx.lineWidth = isHovered ? 3 : 2;
  cityCtx.stroke();
  
  // Icon
  cityCtx.font = `${size * 0.7}px Arial`;
  cityCtx.textAlign = 'center';
  cityCtx.textBaseline = 'middle';
  cityCtx.fillText(colors.icon, x, y - 5);
  
  // Level badge
  if (level > 0) {
    cityCtx.fillStyle = 'rgba(0,0,0,0.7)';
    cityCtx.beginPath();
    cityCtx.arc(x + size * 0.6, y + size * 0.2, 12, 0, Math.PI * 2);
    cityCtx.fill();
    
    cityCtx.fillStyle = '#ffd700';
    cityCtx.font = 'bold 11px Cinzel, serif';
    cityCtx.fillText(level, x + size * 0.6, y + size * 0.2 + 1);
  }
}

function drawBuildingSlot(slot, building, isHovered, isBuilding) {
  const { x, y, size, fixed, fixedKey } = slot;
  
  // Determine what's in this slot
  const key = fixed ? fixedKey : building?.key;
  const level = building?.level || (fixed ? 1 : 0);
  const isEmpty = !key;
  
  // Shadow
  cityCtx.fillStyle = 'rgba(0,0,0,0.4)';
  cityCtx.beginPath();
  cityCtx.ellipse(x + 4, y + 6, size * 0.6, size * 0.3, 0, 0, Math.PI * 2);
  cityCtx.fill();
  
  if (isEmpty) {
    // Empty slot - draw placeholder
    cityCtx.fillStyle = isHovered ? 'rgba(212,168,75,0.5)' : 'rgba(100,80,60,0.5)';
    cityCtx.strokeStyle = isHovered ? '#ffd700' : '#806040';
    cityCtx.lineWidth = isHovered ? 3 : 2;
    cityCtx.setLineDash([5, 5]);
    
    cityCtx.beginPath();
    cityCtx.ellipse(x, y, size * 0.5, size * 0.3, 0, 0, Math.PI * 2);
    cityCtx.fill();
    cityCtx.stroke();
    cityCtx.setLineDash([]);
    
    // Plus icon
    cityCtx.fillStyle = isHovered ? '#ffd700' : '#a08060';
    cityCtx.font = `bold ${size * 0.5}px Arial`;
    cityCtx.textAlign = 'center';
    cityCtx.textBaseline = 'middle';
    cityCtx.fillText('+', x, y);
    
  } else {
    // Building present - draw 2.5D building
    draw25DBuilding(x, y, size, key, level, isHovered, isBuilding);
  }
}

function draw25DBuilding(x, y, size, key, level, isHovered, isBuilding) {
  const buildingStyles = {
    MAIN_HALL: { base: '#c4a060', roof: '#8b4513', height: 1.8, icon: '🏛️' },
    BARRACKS: { base: '#8b7355', roof: '#c44', height: 1.3, icon: '⚔️' },
    STABLE: { base: '#a08060', roof: '#6b4423', height: 1.2, icon: '🐎' },
    WORKSHOP: { base: '#6a5a4a', roof: '#444', height: 1.4, icon: '⚙️' },
    ACADEMY: { base: '#d4c4b4', roof: '#4682B4', height: 1.5, icon: '📚' },
    FORGE: { base: '#5a4a3a', roof: '#333', height: 1.3, icon: '🔨' },
    MARKET: { base: '#c4a484', roof: '#c44', height: 1.0, icon: '🏪' },
    WAREHOUSE: { base: '#8b7355', roof: '#5a4a3a', height: 1.3, icon: '📦' },
    SILO: { base: '#c4a484', roof: '#c44', height: 1.6, icon: '🏺' },
    WALL: { base: '#7a7a7a', roof: '#5a5a5a', height: 1.2, icon: '🏰' },
    HEALING_TENT: { base: '#f0f0e0', roof: '#fff', height: 1.0, icon: '⛺' },
    RALLY_POINT: { base: '#6a5a4a', roof: '#c44', height: 0.8, icon: '🚩' },
    HIDEOUT: { base: '#5a4a3a', roof: '#3a3a2a', height: 0.6, icon: '🕳️' },
    MOAT: { base: '#4682B4', roof: '#4682B4', height: 0.3, icon: '💧' }
  };
  
  const style = buildingStyles[key] || { base: '#a08060', roof: '#6b4423', height: 1.2, icon: '🏠' };
  const buildingHeight = size * style.height;
  
  // Hover glow
  if (isHovered) {
    cityCtx.shadowColor = '#ffd700';
    cityCtx.shadowBlur = 25;
  }
  
  // Building animation for construction
  if (isBuilding) {
    cityCtx.globalAlpha = 0.5 + Math.sin(Date.now() / 200) * 0.3;
  }
  
  // Base (ellipse)
  cityCtx.fillStyle = style.base;
  cityCtx.beginPath();
  cityCtx.ellipse(x, y, size * 0.55, size * 0.3, 0, 0, Math.PI * 2);
  cityCtx.fill();
  
  // Walls (left side)
  cityCtx.fillStyle = shadeColor(style.base, -20);
  cityCtx.beginPath();
  cityCtx.moveTo(x - size * 0.55, y);
  cityCtx.lineTo(x - size * 0.55, y - buildingHeight);
  cityCtx.lineTo(x, y - buildingHeight - size * 0.15);
  cityCtx.lineTo(x, y - size * 0.3);
  cityCtx.closePath();
  cityCtx.fill();
  
  // Walls (right side)
  cityCtx.fillStyle = shadeColor(style.base, -40);
  cityCtx.beginPath();
  cityCtx.moveTo(x + size * 0.55, y);
  cityCtx.lineTo(x + size * 0.55, y - buildingHeight);
  cityCtx.lineTo(x, y - buildingHeight - size * 0.15);
  cityCtx.lineTo(x, y - size * 0.3);
  cityCtx.closePath();
  cityCtx.fill();
  
  // Roof
  cityCtx.fillStyle = style.roof;
  cityCtx.beginPath();
  cityCtx.ellipse(x, y - buildingHeight, size * 0.55, size * 0.3, 0, 0, Math.PI * 2);
  cityCtx.fill();
  
  // Roof top (pointed)
  if (style.height > 0.5) {
    cityCtx.fillStyle = shadeColor(style.roof, -20);
    cityCtx.beginPath();
    cityCtx.moveTo(x, y - buildingHeight - size * 0.5);
    cityCtx.lineTo(x - size * 0.4, y - buildingHeight + size * 0.1);
    cityCtx.lineTo(x + size * 0.4, y - buildingHeight + size * 0.1);
    cityCtx.closePath();
    cityCtx.fill();
  }
  
  cityCtx.shadowBlur = 0;
  cityCtx.globalAlpha = 1;
  
  // Icon on front
  cityCtx.font = `${size * 0.4}px Arial`;
  cityCtx.textAlign = 'center';
  cityCtx.textBaseline = 'middle';
  cityCtx.fillText(style.icon, x, y - buildingHeight / 2);
  
  // Level badge
  if (level > 0) {
    const badgeX = x + size * 0.4;
    const badgeY = y - buildingHeight - size * 0.3;
    
    cityCtx.fillStyle = 'rgba(0,0,0,0.8)';
    cityCtx.beginPath();
    cityCtx.arc(badgeX, badgeY, 12, 0, Math.PI * 2);
    cityCtx.fill();
    
    cityCtx.strokeStyle = '#ffd700';
    cityCtx.lineWidth = 2;
    cityCtx.stroke();
    
    cityCtx.fillStyle = '#ffd700';
    cityCtx.font = 'bold 11px Cinzel, serif';
    cityCtx.fillText(level, badgeX, badgeY + 1);
  }
  
  // Construction indicator
  if (isBuilding) {
    cityCtx.fillStyle = 'rgba(255,165,0,0.8)';
    cityCtx.font = '16px Arial';
    cityCtx.fillText('🔨', x, y - buildingHeight - size * 0.6);
  }
}

function shadeColor(color, percent) {
  const num = parseInt(color.replace('#', ''), 16);
  const amt = Math.round(2.55 * percent);
  const R = Math.max(0, Math.min(255, (num >> 16) + amt));
  const G = Math.max(0, Math.min(255, ((num >> 8) & 0x00FF) + amt));
  const B = Math.max(0, Math.min(255, (num & 0x0000FF) + amt));
  return `#${(0x1000000 + R * 0x10000 + G * 0x100 + B).toString(16).slice(1)}`;
}

function getBuildingAtSlot(slotNum) {
  return currentCity?.buildings?.find(b => b.slot === slotNum);
}

function onCityMouseMove(e) {
  const rect = cityCanvas.getBoundingClientRect();
  const mouseX = (e.clientX - rect.left) * (cityCanvas.width / rect.width);
  const mouseY = (e.clientY - rect.top) * (cityCanvas.height / rect.height);
  
  // Find hovered slot
  let foundSlot = null;
  for (const slot of citySlots) {
    const dx = mouseX - slot.x;
    const dy = mouseY - slot.y;
    const dist = Math.sqrt(dx * dx + dy * dy / 0.36); // Adjust for ellipse
    
    if (dist < slot.size * 0.7) {
      foundSlot = slot.slot;
      break;
    }
  }
  
  if (foundSlot !== cityHoveredSlot) {
    cityHoveredSlot = foundSlot;
    renderCityCanvas();
    
    if (foundSlot !== null) {
      showCityTooltip(e.clientX, e.clientY, foundSlot);
    } else {
      hideCityTooltip();
    }
  }
}

function onCityClick(e) {
  if (cityHoveredSlot !== null) {
    if (currentCityView === 'fields') {
      // Vue champs
      if (cityHoveredSlot === -1) {
        // Clic sur le centre village -> retour vue ville
        switchCityView('city');
      } else {
        // Clic sur un champ -> ouvrir panel construction champ
        openFieldBuildPanel(cityHoveredSlot);
      }
    } else {
      // Vue ville -> ouvrir panel construction normal
      openBuildPanel(cityHoveredSlot);
    }
  }
}

function showCityTooltip(mouseX, mouseY, slotNum) {
  const tooltip = document.getElementById('city-tooltip');
  if (!tooltip) return;
  
  const slot = citySlots.find(s => s.slot === slotNum);
  
  let html = '';
  
  if (currentCityView === 'fields') {
    // Vue champs
    if (slot?.isVillageCenter) {
      html = `
        <h4>🏰 Centre du Village</h4>
        <p class="tt-hint">Cliquez pour voir les bâtiments</p>
      `;
    } else if (slot?.isField) {
      const fieldNames = { 
        FARM: 'Champ de blé', 
        LUMBER: 'Forêt', 
        QUARRY: 'Carrière de pierre', 
        IRON_MINE: 'Mine de fer' 
      };
      const building = getFieldBuildingAtSlot(slot.slot, slot.fieldType);
      const level = building?.level || 0;
      
      html = `
        <h4>${fieldNames[slot.fieldType] || 'Ressource'}</h4>
        <p class="tt-level">Niveau ${level}</p>
        <p class="tt-hint">${level === 0 ? 'Cliquez pour construire' : 'Cliquez pour améliorer'}</p>
      `;
    }
  } else {
    // Vue ville
    const building = getBuildingAtSlot(slotNum);
    
    if (building) {
      html = `
        <h4>${BUILDING_ICONS[building.key] || '🏠'} ${getBuildingName(building.key)}</h4>
        <p class="tt-level">Niveau ${building.level}</p>
        <p class="tt-hint">Cliquez pour améliorer</p>
      `;
    } else if (slot?.fixed) {
      const mainHall = getBuildingAtSlot(0);
      html = `
        <h4>🏛️ Hôtel de Ville</h4>
        <p class="tt-level">Niveau ${mainHall?.level || 1}</p>
        <p class="tt-hint">Bâtiment principal</p>
      `;
    } else {
      html = `
        <h4>Emplacement vide</h4>
        <p class="tt-hint">Cliquez pour construire</p>
      `;
    }
  }
  
  tooltip.innerHTML = html;
  tooltip.style.display = 'block';
  
  const canvasRect = cityCanvas.parentElement.getBoundingClientRect();
  tooltip.style.left = `${mouseX - canvasRect.left + 15}px`;
  tooltip.style.top = `${mouseY - canvasRect.top - 10}px`;
}

function hideCityTooltip() {
  const tooltip = document.getElementById('city-tooltip');
  if (tooltip) tooltip.style.display = 'none';
}

// ========== BUILD PANEL ==========
let selectedBuildSlot = null;

function openBuildPanel(slotNum) {
  selectedBuildSlot = slotNum;
  const panel = document.getElementById('build-panel');
  const content = document.getElementById('build-panel-content');
  const title = document.getElementById('build-panel-title');
  
  const slot = citySlots.find(s => s.slot === slotNum);
  const building = getBuildingAtSlot(slotNum);
  
  // Create overlay
  let overlay = document.querySelector('.build-panel-overlay');
  if (!overlay) {
    overlay = document.createElement('div');
    overlay.className = 'build-panel-overlay';
    overlay.onclick = closeBuildPanel;
    document.body.appendChild(overlay);
  }
  overlay.style.display = 'block';
  
  if (building || slot?.fixed) {
    // Existing building - show upgrade
    const key = building?.key || slot?.fixedKey;
    const level = building?.level || 1;
    const def = buildingsData.find(b => b.key === key);
    const maxLevel = def?.maxLevel || 20;
    const canUpgrade = level < maxLevel;
    
    title.textContent = 'Améliorer';
    content.innerHTML = `
      <div class="current-building">
        <div class="current-building-icon">${BUILDING_ICONS[key] || '🏠'}</div>
        <h4>${getBuildingName(key)}</h4>
        <span class="level-badge">Niveau ${level}</span>
      </div>
      ${canUpgrade ? `
        <div class="upgrade-info">
          <h5>Améliorer au niveau ${level + 1}</h5>
          <div class="upgrade-cost">
            <span>🪵 ${formatNum((def?.costL1?.wood || 50) * (level + 1))}</span>
            <span>🪨 ${formatNum((def?.costL1?.stone || 50) * (level + 1))}</span>
            <span>⛏️ ${formatNum((def?.costL1?.iron || 50) * (level + 1))}</span>
            <span>🌾 ${formatNum((def?.costL1?.food || 30) * (level + 1))}</span>
          </div>
          <button class="build-option-btn" onclick="upgradeBuilding('${key}', ${slotNum})">
            Améliorer
          </button>
        </div>
      ` : `<p style="text-align:center;color:#666;">Niveau maximum atteint</p>`}
    `;
  } else if (slot?.isField) {
    // Resource field - show specific building
    const fieldKey = slot.fieldType;
    const def = buildingsData.find(b => b.key === fieldKey);
    
    title.textContent = 'Construire';
    content.innerHTML = `
      <div class="build-option" onclick="buildAtSlot('${fieldKey}', ${slotNum})">
        <div class="build-option-icon">${BUILDING_ICONS[fieldKey] || '🌾'}</div>
        <div class="build-option-info">
          <h4>${getBuildingName(fieldKey)}</h4>
          <p>Production de ${fieldKey === 'FARM' ? 'nourriture' : fieldKey === 'LUMBER' ? 'bois' : fieldKey === 'QUARRY' ? 'pierre' : 'fer'}</p>
          <div class="build-option-cost">
            <span>🪵 ${def?.costL1?.wood || 50}</span>
            <span>🪨 ${def?.costL1?.stone || 50}</span>
            <span>⛏️ ${def?.costL1?.iron || 50}</span>
          </div>
        </div>
        <button class="build-option-btn">Construire</button>
      </div>
    `;
  } else {
    // Empty slot - show building options
    title.textContent = 'Construire';
    
    const availableBuildings = buildingsData.filter(b => 
      !['FARM', 'LUMBER', 'QUARRY', 'IRON_MINE', 'MAIN_HALL'].includes(b.key)
    );
    
    content.innerHTML = availableBuildings.map(b => `
      <div class="build-option" onclick="buildAtSlot('${b.key}', ${slotNum})">
        <div class="build-option-icon">${BUILDING_ICONS[b.key] || '🏠'}</div>
        <div class="build-option-info">
          <h4>${b.name}</h4>
          <p>${getBuildingDescription(b.key)}</p>
          <div class="build-option-cost">
            <span>🪵 ${b.costL1?.wood || 50}</span>
            <span>🪨 ${b.costL1?.stone || 50}</span>
            <span>⛏️ ${b.costL1?.iron || 50}</span>
          </div>
        </div>
        <button class="build-option-btn">Construire</button>
      </div>
    `).join('');
  }
  
  panel.style.display = 'block';
}

function closeBuildPanel() {
  document.getElementById('build-panel').style.display = 'none';
  const overlay = document.querySelector('.build-panel-overlay');
  if (overlay) overlay.style.display = 'none';
  selectedBuildSlot = null;
}

function openFieldBuildPanel(slotNum) {
  const slot = citySlots.find(s => s.slot === slotNum);
  if (!slot || !slot.isField) return;
  
  selectedBuildSlot = slotNum;
  const panel = document.getElementById('build-panel');
  const content = document.getElementById('build-panel-content');
  const title = document.getElementById('build-panel-title');
  
  const fieldType = slot.fieldType;
  const building = getFieldBuildingAtSlot(slotNum, fieldType);
  const level = building?.level || 0;
  const def = buildingsData.find(b => b.key === fieldType);
  
  const fieldNames = { 
    FARM: 'Ferme', 
    LUMBER: 'Bûcheron', 
    QUARRY: 'Carrière de pierre', 
    IRON_MINE: 'Mine de fer' 
  };
  
  const fieldIcons = {
    FARM: '🌾',
    LUMBER: '🌲',
    QUARRY: '⛰️',
    IRON_MINE: '⛏️'
  };
  
  // Create overlay
  let overlay = document.querySelector('.build-panel-overlay');
  if (!overlay) {
    overlay = document.createElement('div');
    overlay.className = 'build-panel-overlay';
    overlay.onclick = closeBuildPanel;
    document.body.appendChild(overlay);
  }
  overlay.style.display = 'block';
  
  if (level > 0) {
    // Existing field - show upgrade
    const maxLevel = def?.maxLevel || 20;
    const canUpgrade = level < maxLevel;
    
    title.textContent = 'Améliorer';
    content.innerHTML = `
      <div class="current-building">
        <div class="current-building-icon">${fieldIcons[fieldType]}</div>
        <h4>${fieldNames[fieldType]}</h4>
        <span class="level-badge">Niveau ${level}</span>
        <p style="margin-top:10px;font-size:12px;color:#666">
          Production: +${level * 30}/h
        </p>
      </div>
      ${canUpgrade ? `
        <div class="upgrade-info">
          <h5>Améliorer au niveau ${level + 1}</h5>
          <p style="font-size:12px;color:#666;margin-bottom:10px">
            Production: +${(level + 1) * 30}/h (+30/h)
          </p>
          <div class="upgrade-cost">
            <span>🪵 ${formatNum((def?.costL1?.wood || 50) * (level + 1))}</span>
            <span>🪨 ${formatNum((def?.costL1?.stone || 50) * (level + 1))}</span>
            <span>⛏️ ${formatNum((def?.costL1?.iron || 50) * (level + 1))}</span>
          </div>
          <button class="build-option-btn" onclick="buildField('${fieldType}', ${slotNum + 100})">
            Améliorer
          </button>
        </div>
      ` : `<p style="text-align:center;color:#666;">Niveau maximum atteint</p>`}
    `;
  } else {
    // Empty field - show build option
    title.textContent = 'Construire';
    content.innerHTML = `
      <div class="build-option" onclick="buildField('${fieldType}', ${slotNum + 100})">
        <div class="build-option-icon">${fieldIcons[fieldType]}</div>
        <div class="build-option-info">
          <h4>${fieldNames[fieldType]}</h4>
          <p>Production de ${fieldType === 'FARM' ? 'nourriture' : fieldType === 'LUMBER' ? 'bois' : fieldType === 'QUARRY' ? 'pierre' : 'fer'}</p>
          <p style="font-size:11px;color:#888">+30/h au niveau 1</p>
          <div class="build-option-cost">
            <span>🪵 ${def?.costL1?.wood || 50}</span>
            <span>🪨 ${def?.costL1?.stone || 50}</span>
            <span>⛏️ ${def?.costL1?.iron || 50}</span>
          </div>
        </div>
        <button class="build-option-btn">Construire</button>
      </div>
    `;
  }
  
  panel.style.display = 'block';
}

async function buildField(buildingKey, slot) {
  const res = await fetch(`${API}/api/city/${currentCity.id}/build`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify({ buildingKey, slot })
  });
  
  const data = await res.json();
  closeBuildPanel();
  
  if (res.ok) {
    showToast(`Construction de ${getBuildingName(buildingKey)} lancée!`, 'success');
    await loadCities();
    renderCity();
  } else {
    showToast(data.error || 'Erreur', 'error');
  }
}

async function buildAtSlot(buildingKey, slot) {
  const res = await fetch(`${API}/api/city/${currentCity.id}/build`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify({ buildingKey, slot })
  });
  
  const data = await res.json();
  closeBuildPanel();
  
  if (res.ok) {
    showToast(`Construction de ${getBuildingName(buildingKey)} lancée!`, 'success');
    await loadCities();
    renderCity();
  } else {
    showToast(data.error || 'Erreur', 'error');
  }
}

async function upgradeBuilding(buildingKey, slot) {
  await buildAtSlot(buildingKey, slot);
}

function getBuildingDescription(key) {
  const descriptions = {
    BARRACKS: 'Entraîne l\'infanterie',
    STABLE: 'Entraîne la cavalerie',
    WORKSHOP: 'Construit des machines de siège',
    ACADEMY: 'Recherche et formation',
    FORGE: 'Améliore l\'équipement',
    MARKET: 'Commerce et échanges',
    WAREHOUSE: 'Stocke les ressources',
    SILO: 'Stocke la nourriture',
    WALL: 'Défense de la ville',
    HEALING_TENT: 'Soigne les blessés',
    RALLY_POINT: 'Rassemblement des armées',
    HIDEOUT: 'Cache des ressources',
    MOAT: 'Douves défensives'
  };
  return descriptions[key] || 'Bâtiment';
}

// Handle window resize for city canvas
window.addEventListener('resize', () => {
  if (cityCanvas && document.getElementById('tab-city').classList.contains('active')) {
    const container = cityCanvas.parentElement;
    cityCanvas.width = container.clientWidth;
    cityCanvas.height = container.clientHeight;
    calculateCitySlots();
    renderCityCanvas();
  }
});

// Animation loop for construction
setInterval(() => {
  if (document.getElementById('tab-city')?.classList.contains('active') && 
      currentCity?.buildQueue?.some(q => q.status === 'RUNNING')) {
    renderCityCanvas();
  }
}, 100);

function renderBuildingSlots() {
  // Legacy function - now handled by renderCityCanvas
  renderCityCanvas();
}

function renderBuildQueue() {
  const el = document.getElementById('build-queue');
  if (!currentCity.buildQueue || currentCity.buildQueue.length === 0) {
    el.innerHTML = '<p style="padding:10px;color:var(--text-muted);font-size:12px;">Aucune construction</p>';
    return;
  }
  
  el.innerHTML = currentCity.buildQueue.map(q => `
    <div class="queue-item">
      <span class="queue-name">${BUILDING_ICONS[q.buildingKey] || '🏠'} ${getBuildingName(q.buildingKey)} Niv.${q.targetLevel}</span>
      <span class="queue-time">${formatTime(q.endsAt)}</span>
    </div>
  `).join('');
}

function renderRecruitQueue() {
  const el = document.getElementById('recruit-queue');
  if (!currentCity.recruitQueue || currentCity.recruitQueue.length === 0) {
    el.innerHTML = '<p style="padding:10px;color:var(--text-muted);font-size:12px;">Aucun recrutement</p>';
    return;
  }
  
  el.innerHTML = currentCity.recruitQueue.map(q => `
    <div class="queue-item">
      <span class="queue-name">${q.count}x ${q.unitKey}</span>
      <span class="queue-time">${formatTime(q.endsAt)}</span>
    </div>
  `).join('');
}

function renderMovingArmies() {
  const el = document.getElementById('moving-armies');
  const moving = armies.filter(a => a.status !== 'IDLE');
  
  if (moving.length === 0) {
    el.innerHTML = '<p style="padding:10px;color:var(--text-muted);font-size:12px;">Aucune armée en mouvement</p>';
    return;
  }
  
  el.innerHTML = moving.map(a => `
    <div class="queue-item">
      <span class="queue-name">${a.name} (${a.status})</span>
      <span class="queue-time">${a.arrivalAt ? formatTime(a.arrivalAt) : '-'}</span>
    </div>
  `).join('');
}

// ========== TABS ==========
function showTab(tabName) {
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  
  document.getElementById(`tab-${tabName}`).classList.add('active');
  document.querySelector(`[data-tab="${tabName}"]`)?.classList.add('active');
  
  // Load tab content
  switch(tabName) {
    case 'city': renderCity(); break;
    case 'buildings': loadBuildings(); break;
    case 'army': renderArmies(); break;
    case 'recruit': loadUnits(); break;
    case 'hero': loadHero(); break;
    case 'expeditions': loadExpeditions(); break;
    case 'map': loadMap(); break;
    case 'alliance': loadAlliance(); break;
    case 'ranking': loadRanking('players'); break;
    case 'reports': loadReports(); break;
  }
}

// ========== BUILDINGS ==========
let buildingsData = [];

async function loadBuildings() {
  if (buildingsData.length === 0) {
    const res = await fetch(`${API}/api/buildings`, { headers: { Authorization: `Bearer ${token}` } });
    if (res.ok) buildingsData = await res.json();
  }
  renderBuildings('all');
}

function filterBuildings(category) {
  document.querySelectorAll('.cat-btn').forEach(b => b.classList.remove('active'));
  event.target.classList.add('active');
  renderBuildings(category);
}

function renderBuildings(filter) {
  const grid = document.getElementById('buildings-grid');
  let buildings = buildingsData;
  
  if (filter !== 'all') {
    buildings = buildings.filter(b => b.category === filter);
  }
  
  grid.innerHTML = buildings.map(b => {
    const existing = currentCity?.buildings?.find(cb => cb.key === b.key);
    const level = existing?.level || 0;
    const nextLevel = level + 1;
    const canBuild = nextLevel <= b.maxLevel;
    
    return `
      <div class="card">
        <h3>${BUILDING_ICONS[b.key] || '🏠'} ${b.name}</h3>
        <p>Niveau actuel: ${level} / ${b.maxLevel}</p>
        <div class="stats">
          Coût: 🪵${formatNum(b.costL1?.wood || 50)} 🪨${formatNum(b.costL1?.stone || 50)} ⛏️${formatNum(b.costL1?.iron || 50)} 🌾${formatNum(b.costL1?.food || 50)}
        </div>
        ${canBuild ? `<button onclick="build('${b.key}')">Construire Niv.${nextLevel}</button>` : '<p style="padding:10px;color:var(--gold);">Niveau max</p>'}
      </div>
    `;
  }).join('');
}

async function build(buildingKey) {
  const res = await fetch(`${API}/api/city/${currentCity.id}/build`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify({ buildingKey })
  });
  
  const data = await res.json();
  if (res.ok) {
    showToast('Construction lancée!', 'success');
    await loadCities();
    renderCity();
    loadBuildings();
  } else {
    showToast(data.error || 'Erreur', 'error');
  }
}

// ========== UNITS ==========
let unitsData = [];

async function loadUnits() {
  if (unitsData.length === 0) {
    const res = await fetch(`${API}/api/units`, { headers: { Authorization: `Bearer ${token}` } });
    if (res.ok) unitsData = await res.json();
  }
  renderUnits('all');
}

function filterUnits(classFilter) {
  document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
  event.target.classList.add('active');
  renderUnits(classFilter);
}

function renderUnits(filter) {
  const grid = document.getElementById('units-grid');
  let units = unitsData.filter(u => u.faction === player?.faction);
  
  if (filter !== 'all') {
    units = units.filter(u => u.class === filter);
  }
  
  grid.innerHTML = units.map(u => `
    <div class="card">
      <h3 style="border-left: 4px solid ${TIER_COLORS[u.tier]}">${UNIT_ICONS[u.class] || '⚔️'} ${u.name}</h3>
      <p style="color:${TIER_COLORS[u.tier]}">${u.tier.toUpperCase()}</p>
      <div class="stats">
        ⚔️${u.stats?.attack || 0} 🛡️${u.stats?.defense || 0} ❤️${u.stats?.endurance || 0} 🏃${u.stats?.speed || 0}
      </div>
      <button onclick="showRecruitModal('${u.key}', '${u.name}')">Recruter</button>
    </div>
  `).join('');
}

function showRecruitModal(unitKey, unitName) {
  const modal = document.getElementById('modal');
  document.getElementById('modal-body').innerHTML = `
    <h3>Recruter ${unitName}</h3>
    <input type="number" id="recruit-count" value="10" min="1" max="1000" placeholder="Nombre">
    <button onclick="recruit('${unitKey}')" class="btn">Recruter</button>
  `;
  modal.style.display = 'flex';
}

async function recruit(unitKey) {
  const count = parseInt(document.getElementById('recruit-count').value) || 1;
  
  const res = await fetch(`${API}/api/city/${currentCity.id}/recruit`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify({ unitKey, count })
  });
  
  const data = await res.json();
  closeModal();
  
  if (res.ok) {
    showToast(`Recrutement de ${count}x ${unitKey} lancé!`, 'success');
    await loadCities();
    renderCity();
  } else {
    showToast(data.error || 'Erreur', 'error');
  }
}

// ========== ARMIES ==========
function renderArmies() {
  const container = document.getElementById('armies-list');
  
  if (armies.length === 0) {
    container.innerHTML = '<p style="color:var(--text-muted)">Aucune armée</p>';
    return;
  }
  
  container.innerHTML = armies.map(a => `
    <div class="army-card">
      <div class="army-header">
        <span class="army-name">${a.name}</span>
        <span class="army-status ${a.status.toLowerCase()}">${a.status}</span>
      </div>
      <div class="army-units">
        ${a.units?.map(u => `
          <div class="army-unit">
            <span>${u.unitKey}</span>
            <span class="army-unit-count">x${u.count}</span>
          </div>
        `).join('') || '<span style="color:var(--text-muted)">Aucune unité</span>'}
      </div>
      <div style="padding:10px;font-size:12px;color:var(--text-muted)">
        Position: (${a.x}, ${a.y}) | Puissance: ${a.power || 0}
      </div>
      <div class="army-actions">
        ${a.status === 'IDLE' ? `
          <button class="btn btn-secondary" onclick="showMoveModal('${a.id}')">Déplacer</button>
          <button class="btn btn-danger" onclick="showAttackModal('${a.id}')">Attaquer</button>
          <button class="btn" style="background:linear-gradient(180deg,orange,#c70)" onclick="showRaidModal('${a.id}')">Piller</button>
        ` : `
          <button class="btn btn-secondary" onclick="returnArmy('${a.id}')">Rappeler</button>
        `}
      </div>
    </div>
  `).join('');
}

function showMoveModal(armyId) {
  document.getElementById('modal-body').innerHTML = `
    <h3>Déplacer l'armée</h3>
    <input type="number" id="move-x" placeholder="X" style="width:48%;display:inline-block">
    <input type="number" id="move-y" placeholder="Y" style="width:48%;display:inline-block">
    <button onclick="moveArmy('${armyId}')" class="btn">Déplacer</button>
  `;
  document.getElementById('modal').style.display = 'flex';
}

async function moveArmy(armyId) {
  const x = parseInt(document.getElementById('move-x').value);
  const y = parseInt(document.getElementById('move-y').value);
  
  const res = await fetch(`${API}/api/army/${armyId}/move`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify({ x, y })
  });
  
  const data = await res.json();
  closeModal();
  
  if (res.ok) {
    showToast('Armée en mouvement!', 'success');
    await loadArmies();
    renderArmies();
  } else {
    showToast(data.error || 'Erreur', 'error');
  }
}

function showAttackModal(armyId) {
  document.getElementById('modal-body').innerHTML = `
    <h3>Attaquer une ville</h3>
    <p style="margin-bottom:10px;color:var(--wood-medium)">Entrez l'ID de la ville cible</p>
    <input type="text" id="attack-city" placeholder="ID de la ville cible">
    <button onclick="attackCity('${armyId}')" class="btn btn-danger">Attaquer!</button>
  `;
  document.getElementById('modal').style.display = 'flex';
}

async function attackCity(armyId) {
  const targetCityId = document.getElementById('attack-city').value;
  
  const res = await fetch(`${API}/api/army/${armyId}/attack`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify({ targetCityId })
  });
  
  const data = await res.json();
  closeModal();
  
  if (res.ok) {
    showToast(`Attaque lancée contre ${data.target}!`, 'success');
    await loadArmies();
    renderArmies();
  } else {
    showToast(data.error || 'Erreur', 'error');
  }
}

function showRaidModal(armyId) {
  document.getElementById('modal-body').innerHTML = `
    <h3>Piller une ville</h3>
    <p style="margin-bottom:10px;color:var(--wood-medium)">Volez des ressources à l'ennemi!</p>
    <input type="text" id="raid-city" placeholder="ID de la ville cible">
    <button onclick="raidCity('${armyId}')" class="btn" style="background:linear-gradient(180deg,orange,#c70)">Piller!</button>
  `;
  document.getElementById('modal').style.display = 'flex';
}

async function raidCity(armyId) {
  const targetCityId = document.getElementById('raid-city').value;
  
  const res = await fetch(`${API}/api/army/${armyId}/raid`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify({ targetCityId })
  });
  
  const data = await res.json();
  closeModal();
  
  if (res.ok) {
    showToast(`Raid lancé contre ${data.target}!`, 'success');
    await loadArmies();
    renderArmies();
  } else {
    showToast(data.error || 'Erreur', 'error');
  }
}

async function returnArmy(armyId) {
  const res = await fetch(`${API}/api/army/${armyId}/return`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}` }
  });
  
  const data = await res.json();
  if (res.ok) {
    showToast('Armée rappelée!', 'success');
    await loadArmies();
    renderArmies();
  } else {
    showToast(data.error || 'Erreur', 'error');
  }
}

// ========== HERO ==========
async function loadHero() {
  const res = await fetch(`${API}/api/hero`, { headers: { Authorization: `Bearer ${token}` } });
  const panel = document.getElementById('hero-panel');
  
  if (res.ok) {
    const hero = await res.json();
    if (hero) {
      const xpPct = (hero.xp / hero.xpToNextLevel) * 100;
      panel.innerHTML = `
        <div class="hero-card">
          <div class="hero-header">
            <div class="hero-portrait">⚔️</div>
            <div class="hero-info">
              <h3>${hero.name}</h3>
              <div class="hero-level">Niveau ${hero.level}</div>
              <div class="hero-xp">
                <div class="xp-bar"><div class="xp-fill" style="width:${xpPct}%"></div></div>
                <div class="xp-text">${hero.xp} / ${hero.xpToNextLevel} XP</div>
              </div>
            </div>
          </div>
          <div class="hero-stats">
            <div class="stat-item"><span class="stat-name">⚔️ Attaque</span><span class="stat-value">${hero.atkPoints}</span></div>
            <div class="stat-item"><span class="stat-name">🛡️ Défense</span><span class="stat-value">${hero.defPoints}</span></div>
            <div class="stat-item"><span class="stat-name">🏃 Vitesse</span><span class="stat-value">${hero.spdPoints}</span></div>
            <div class="stat-item"><span class="stat-name">📦 Logistique</span><span class="stat-value">${hero.logPoints}</span></div>
          </div>
          ${hero.statPoints > 0 ? `
            <div class="hero-points">
              <div class="points-available">Points disponibles: ${hero.statPoints}</div>
              <div class="points-grid">
                <button class="point-btn" onclick="assignPoint('atk')">+ATK</button>
                <button class="point-btn" onclick="assignPoint('def')">+DEF</button>
                <button class="point-btn" onclick="assignPoint('spd')">+SPD</button>
                <button class="point-btn" onclick="assignPoint('log')">+LOG</button>
              </div>
            </div>
          ` : ''}
        </div>
      `;
    } else {
      panel.innerHTML = '<p style="color:var(--text-muted)">Aucun héros</p>';
    }
  }
}

async function assignPoint(stat) {
  const body = { atk: 0, def: 0, spd: 0, log: 0 };
  body[stat] = 1;
  
  const res = await fetch(`${API}/api/hero/assign-points`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify(body)
  });
  
  if (res.ok) {
    showToast('Point assigné!', 'success');
    loadHero();
  }
}

// ========== EXPEDITIONS ==========
async function loadExpeditions() {
  const res = await fetch(`${API}/api/expeditions`, { headers: { Authorization: `Bearer ${token}` } });
  
  if (res.ok) {
    const expeditions = await res.json();
    const available = expeditions.filter(e => e.status === 'AVAILABLE');
    const history = expeditions.filter(e => e.status !== 'AVAILABLE');
    
    document.getElementById('expeditions-available').innerHTML = available.length > 0 
      ? available.map(e => `
          <div class="expedition-card">
            <div class="exp-difficulty"><span class="exp-stars">${'⭐'.repeat(e.difficulty)}</span></div>
            <h4>Expédition ${e.difficulty > 2 ? 'Difficile' : 'Standard'}</h4>
            <p>Puissance ennemie: ${e.enemyPower}</p>
            <p>Durée: ${Math.floor(e.duration / 60)} min</p>
            <div class="exp-loot"><span class="loot-badge ${e.lootTier}">${e.lootTier}</span></div>
            <button onclick="startExpedition('${e.id}')" class="btn">Lancer</button>
          </div>
        `).join('')
      : '<p style="color:var(--text-muted)">Aucune expédition disponible</p>';
    
    document.getElementById('expeditions-history').innerHTML = history.slice(0, 10).map(e => `
      <div class="queue-item">
        <span>${e.won ? '✅' : '❌'} Difficulté ${e.difficulty}</span>
        <span class="loot-badge ${e.lootTier}">${e.xpGained || 0} XP</span>
      </div>
    `).join('') || '<p style="color:var(--text-muted)">Aucun historique</p>';
  }
}

async function startExpedition(id) {
  const army = armies.find(a => a.status === 'IDLE' && a.units?.length > 0);
  if (!army) {
    showToast('Aucune armée disponible', 'error');
    return;
  }
  
  const res = await fetch(`${API}/api/expedition/${id}/start`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify({ armyId: army.id })
  });
  
  if (res.ok) {
    showToast('Expédition lancée!', 'success');
    await loadArmies();
    loadExpeditions();
  } else {
    const data = await res.json();
    showToast(data.error || 'Erreur', 'error');
  }
}

// ========== MAP - Rise of Kingdoms Style Canvas ==========
let mapCanvas, mapCtx, minimapCanvas, minimapCtx;
let mapData = [];
let mapZoomLevel = 1;
let mapOffsetX = 0, mapOffsetY = 0;
let mapDragging = false;
let mapDragStart = { x: 0, y: 0 };
let mapHoveredTile = null;
let mapSelectedTile = null;
const TILE_SIZE = 40;
const WORLD_SIZE = 200; // 200x200 world

// Colors for different tile types
const TILE_COLORS = {
  empty: ['#2a4a2a', '#2e4e2e', '#264626', '#324e32'],
  myCity: { fill: '#d4a84b', stroke: '#8b6914', glow: '#ffd700' },
  enemyCity: { fill: '#c44444', stroke: '#822222', glow: '#ff6060' },
  allyCity: { fill: '#44aa88', stroke: '#228866', glow: '#66ffcc' },
  wood: { fill: '#4a7a3a', stroke: '#3a5a2a', icon: '🌲' },
  stone: { fill: '#7a7a7a', stroke: '#5a5a5a', icon: '⛰️' },
  iron: { fill: '#5a5a7a', stroke: '#4a4a6a', icon: '⚒️' },
  food: { fill: '#7aa040', stroke: '#5a8020', icon: '🌾' }
};

function initMapCanvas() {
  mapCanvas = document.getElementById('world-canvas');
  mapCtx = mapCanvas?.getContext('2d');
  minimapCanvas = document.getElementById('minimap-canvas');
  minimapCtx = minimapCanvas?.getContext('2d');
  
  if (!mapCanvas || !mapCtx) return;
  
  // Resize canvas to container
  const container = mapCanvas.parentElement;
  mapCanvas.width = container.clientWidth;
  mapCanvas.height = container.clientHeight;
  
  // Event listeners
  mapCanvas.addEventListener('mousedown', onMapMouseDown);
  mapCanvas.addEventListener('mousemove', onMapMouseMove);
  mapCanvas.addEventListener('mouseup', onMapMouseUp);
  mapCanvas.addEventListener('mouseleave', onMapMouseUp);
  mapCanvas.addEventListener('wheel', onMapWheel, { passive: false });
  mapCanvas.addEventListener('click', onMapClick);
  
  // Touch events for mobile
  mapCanvas.addEventListener('touchstart', onMapTouchStart, { passive: false });
  mapCanvas.addEventListener('touchmove', onMapTouchMove, { passive: false });
  mapCanvas.addEventListener('touchend', onMapTouchEnd);
  
  // Center on capital initially
  centerOnCapital();
}

async function loadMap() {
  initMapCanvas();
  
  // Load all visible tiles from server
  const viewSize = Math.ceil(50 / mapZoomLevel);
  const startX = Math.floor(mapOffsetX - viewSize / 2);
  const startY = Math.floor(mapOffsetY - viewSize / 2);
  
  try {
    const res = await fetch(
      `${API}/api/map/viewport?x=${startX}&y=${startY}&zoom=${viewSize}`,
      { headers: { Authorization: `Bearer ${token}` } }
    );
    
    if (res.ok) {
      mapData = await res.json();
    }
  } catch (e) {
    console.warn('Could not load map data');
    // Generate fake data for demo
    mapData = generateFakeMapData(startX, startY, viewSize);
  }
  
  renderMap();
  renderMinimap();
  updateMapUI();
}

function generateFakeMapData(startX, startY, size) {
  const data = [];
  const seed = 12345;
  
  // Add player cities
  cities.forEach(c => {
    data.push({ x: c.x, y: c.y, type: 'CITY', playerId: player?.id, name: c.name, isCapital: c.isCapital });
  });
  
  // Add some random resources and enemy cities
  for (let i = 0; i < 50; i++) {
    const x = startX + Math.floor(Math.random() * size);
    const y = startY + Math.floor(Math.random() * size);
    const types = ['WOOD', 'STONE', 'IRON', 'FOOD'];
    
    if (Math.random() < 0.1) {
      data.push({ x, y, type: 'CITY', playerId: 'enemy', name: `Ville ${i}` });
    } else {
      data.push({ x, y, type: 'RESOURCE', resourceType: types[Math.floor(Math.random() * 4)] });
    }
  }
  
  return data;
}

function renderMap() {
  if (!mapCtx) return;
  
  const w = mapCanvas.width;
  const h = mapCanvas.height;
  const tileSize = TILE_SIZE * mapZoomLevel;
  
  // Clear canvas
  mapCtx.fillStyle = '#1a2a1a';
  mapCtx.fillRect(0, 0, w, h);
  
  // Calculate visible area
  const tilesX = Math.ceil(w / tileSize) + 2;
  const tilesY = Math.ceil(h / tileSize) + 2;
  const startTileX = Math.floor(mapOffsetX - tilesX / 2);
  const startTileY = Math.floor(mapOffsetY - tilesY / 2);
  
  // Draw terrain grid
  for (let ty = 0; ty < tilesY; ty++) {
    for (let tx = 0; tx < tilesX; tx++) {
      const worldX = startTileX + tx;
      const worldY = startTileY + ty;
      
      const screenX = (tx - (mapOffsetX - startTileX)) * tileSize + w / 2;
      const screenY = (ty - (mapOffsetY - startTileY)) * tileSize + h / 2;
      
      // Draw base terrain with slight variation
      const colorIdx = ((worldX + worldY) % 4 + 4) % 4;
      mapCtx.fillStyle = TILE_COLORS.empty[colorIdx];
      mapCtx.fillRect(screenX - tileSize/2, screenY - tileSize/2, tileSize - 1, tileSize - 1);
      
      // Grid lines (subtle)
      if (mapZoomLevel > 0.5) {
        mapCtx.strokeStyle = 'rgba(255,255,255,0.05)';
        mapCtx.strokeRect(screenX - tileSize/2, screenY - tileSize/2, tileSize - 1, tileSize - 1);
      }
    }
  }
  
  // Draw objects (cities, resources)
  mapData.forEach(tile => {
    const screenX = (tile.x - mapOffsetX) * tileSize + w / 2;
    const screenY = (tile.y - mapOffsetY) * tileSize + h / 2;
    
    // Skip if off-screen
    if (screenX < -tileSize || screenX > w + tileSize || 
        screenY < -tileSize || screenY > h + tileSize) return;
    
    if (tile.type === 'CITY') {
      drawCity(screenX, screenY, tileSize, tile);
    } else if (tile.type === 'RESOURCE') {
      drawResource(screenX, screenY, tileSize, tile);
    }
  });
  
  // Draw armies
  armies.forEach(army => {
    const screenX = (army.x - mapOffsetX) * tileSize + w / 2;
    const screenY = (army.y - mapOffsetY) * tileSize + h / 2;
    
    if (screenX >= -tileSize && screenX <= w + tileSize && 
        screenY >= -tileSize && screenY <= h + tileSize) {
      drawArmy(screenX, screenY, tileSize, army);
    }
  });
  
  // Draw hovered tile highlight
  if (mapHoveredTile) {
    const screenX = (mapHoveredTile.x - mapOffsetX) * tileSize + w / 2;
    const screenY = (mapHoveredTile.y - mapOffsetY) * tileSize + h / 2;
    
    mapCtx.strokeStyle = '#ffd700';
    mapCtx.lineWidth = 2;
    mapCtx.strokeRect(screenX - tileSize/2 + 2, screenY - tileSize/2 + 2, tileSize - 5, tileSize - 5);
  }
  
  // Draw selected tile
  if (mapSelectedTile) {
    const screenX = (mapSelectedTile.x - mapOffsetX) * tileSize + w / 2;
    const screenY = (mapSelectedTile.y - mapOffsetY) * tileSize + h / 2;
    
    mapCtx.strokeStyle = '#00ff00';
    mapCtx.lineWidth = 3;
    mapCtx.setLineDash([5, 5]);
    mapCtx.strokeRect(screenX - tileSize/2 + 1, screenY - tileSize/2 + 1, tileSize - 3, tileSize - 3);
    mapCtx.setLineDash([]);
  }
}

function drawCity(x, y, size, tile) {
  const isMyCity = tile.playerId === player?.id;
  const isAlly = tile.allianceId && tile.allianceId === player?.allianceId;
  
  const colors = isMyCity ? TILE_COLORS.myCity : isAlly ? TILE_COLORS.allyCity : TILE_COLORS.enemyCity;
  
  // Shadow
  mapCtx.fillStyle = 'rgba(0,0,0,0.3)';
  mapCtx.beginPath();
  mapCtx.ellipse(x + 2, y + 4, size * 0.4, size * 0.2, 0, 0, Math.PI * 2);
  mapCtx.fill();
  
  // Glow effect for hover
  if (mapHoveredTile && mapHoveredTile.x === tile.x && mapHoveredTile.y === tile.y) {
    mapCtx.shadowColor = colors.glow;
    mapCtx.shadowBlur = 20;
  }
  
  // City wall (ellipse base)
  mapCtx.fillStyle = '#6a6a6a';
  mapCtx.beginPath();
  mapCtx.ellipse(x, y, size * 0.45, size * 0.25, 0, 0, Math.PI * 2);
  mapCtx.fill();
  mapCtx.shadowBlur = 0;
  
  // City ground inside wall
  mapCtx.fillStyle = isMyCity ? '#c4a060' : isAlly ? '#80a080' : '#a08080';
  mapCtx.beginPath();
  mapCtx.ellipse(x, y, size * 0.38, size * 0.2, 0, 0, Math.PI * 2);
  mapCtx.fill();
  
  // Draw mini 2.5D buildings if zoomed enough
  if (mapZoomLevel > 0.6) {
    // Main building (center)
    drawMapBuilding(x, y - size * 0.08, size * 0.25, colors.fill, colors.stroke);
    
    // Side buildings
    if (mapZoomLevel > 0.9) {
      drawMapBuilding(x - size * 0.18, y + size * 0.02, size * 0.15, '#8b7355', '#5a4030');
      drawMapBuilding(x + size * 0.18, y + size * 0.02, size * 0.15, '#8b7355', '#5a4030');
    }
    
    // Towers on wall
    if (mapZoomLevel > 0.8) {
      drawMapTower(x - size * 0.35, y, size * 0.08);
      drawMapTower(x + size * 0.35, y, size * 0.08);
      drawMapTower(x, y - size * 0.2, size * 0.08);
      drawMapTower(x, y + size * 0.2, size * 0.08);
    }
  } else {
    // Simple icon for far zoom
    mapCtx.font = `${size * 0.4}px Arial`;
    mapCtx.textAlign = 'center';
    mapCtx.textBaseline = 'middle';
    mapCtx.fillText('🏰', x, y);
  }
  
  // Capital crown
  if (tile.isCapital && isMyCity) {
    mapCtx.font = `${size * 0.35}px Arial`;
    mapCtx.textAlign = 'center';
    mapCtx.fillText('👑', x, y - size * 0.35);
  }
  
  // Name label (if zoomed in enough)
  if (mapZoomLevel > 0.7 && tile.name) {
    mapCtx.font = `bold ${10 * mapZoomLevel}px Cinzel, serif`;
    mapCtx.fillStyle = '#fff';
    mapCtx.shadowColor = '#000';
    mapCtx.shadowBlur = 3;
    mapCtx.fillText(tile.name, x, y + size * 0.5);
    mapCtx.shadowBlur = 0;
  }
}

function drawMapBuilding(x, y, size, fillColor, strokeColor) {
  const height = size * 1.2;
  
  // Building base
  mapCtx.fillStyle = fillColor;
  mapCtx.beginPath();
  mapCtx.ellipse(x, y, size * 0.5, size * 0.25, 0, 0, Math.PI * 2);
  mapCtx.fill();
  
  // Left wall
  mapCtx.fillStyle = shadeColor(fillColor, -15);
  mapCtx.beginPath();
  mapCtx.moveTo(x - size * 0.5, y);
  mapCtx.lineTo(x - size * 0.5, y - height);
  mapCtx.lineTo(x, y - height - size * 0.15);
  mapCtx.lineTo(x, y - size * 0.25);
  mapCtx.closePath();
  mapCtx.fill();
  
  // Right wall
  mapCtx.fillStyle = shadeColor(fillColor, -30);
  mapCtx.beginPath();
  mapCtx.moveTo(x + size * 0.5, y);
  mapCtx.lineTo(x + size * 0.5, y - height);
  mapCtx.lineTo(x, y - height - size * 0.15);
  mapCtx.lineTo(x, y - size * 0.25);
  mapCtx.closePath();
  mapCtx.fill();
  
  // Roof
  mapCtx.fillStyle = strokeColor;
  mapCtx.beginPath();
  mapCtx.ellipse(x, y - height, size * 0.5, size * 0.25, 0, 0, Math.PI * 2);
  mapCtx.fill();
  
  // Roof point
  mapCtx.fillStyle = shadeColor(strokeColor, -20);
  mapCtx.beginPath();
  mapCtx.moveTo(x, y - height - size * 0.5);
  mapCtx.lineTo(x - size * 0.35, y - height + size * 0.1);
  mapCtx.lineTo(x + size * 0.35, y - height + size * 0.1);
  mapCtx.closePath();
  mapCtx.fill();
}

function drawMapTower(x, y, size) {
  // Tower base
  mapCtx.fillStyle = '#5a5a5a';
  mapCtx.beginPath();
  mapCtx.arc(x, y, size, 0, Math.PI * 2);
  mapCtx.fill();
  
  // Tower body
  mapCtx.fillRect(x - size * 0.7, y - size * 2, size * 1.4, size * 2);
  
  // Tower top
  mapCtx.fillStyle = '#7a7a7a';
  mapCtx.beginPath();
  mapCtx.arc(x, y - size * 2, size * 0.8, 0, Math.PI * 2);
  mapCtx.fill();
  
  // Flag
  mapCtx.fillStyle = '#c44';
  mapCtx.beginPath();
  mapCtx.moveTo(x, y - size * 3);
  mapCtx.lineTo(x + size, y - size * 2.7);
  mapCtx.lineTo(x, y - size * 2.4);
  mapCtx.fill();
}

function drawResource(x, y, size, tile) {
  const resType = tile.resourceType?.toLowerCase() || 'wood';
  const colors = TILE_COLORS[resType] || TILE_COLORS.wood;
  
  // Resource circle
  mapCtx.fillStyle = colors.fill;
  mapCtx.beginPath();
  mapCtx.arc(x, y, size * 0.25, 0, Math.PI * 2);
  mapCtx.fill();
  
  mapCtx.strokeStyle = colors.stroke;
  mapCtx.lineWidth = 1;
  mapCtx.stroke();
  
  // Resource icon
  if (mapZoomLevel > 0.6) {
    mapCtx.font = `${size * 0.35}px Arial`;
    mapCtx.textAlign = 'center';
    mapCtx.textBaseline = 'middle';
    mapCtx.fillText(colors.icon, x, y);
  }
}

function drawArmy(x, y, size, army) {
  const isMoving = army.status !== 'IDLE';
  
  // Army marker
  mapCtx.fillStyle = isMoving ? '#ff8800' : '#4488ff';
  mapCtx.beginPath();
  mapCtx.moveTo(x, y - size * 0.3);
  mapCtx.lineTo(x - size * 0.2, y + size * 0.15);
  mapCtx.lineTo(x + size * 0.2, y + size * 0.15);
  mapCtx.closePath();
  mapCtx.fill();
  
  mapCtx.strokeStyle = '#fff';
  mapCtx.lineWidth = 1;
  mapCtx.stroke();
  
  // Draw movement line
  if (isMoving && army.targetX !== undefined) {
    const targetScreenX = (army.targetX - mapOffsetX) * size + mapCanvas.width / 2;
    const targetScreenY = (army.targetY - mapOffsetY) * size + mapCanvas.height / 2;
    
    mapCtx.strokeStyle = 'rgba(255,136,0,0.5)';
    mapCtx.lineWidth = 2;
    mapCtx.setLineDash([5, 5]);
    mapCtx.beginPath();
    mapCtx.moveTo(x, y);
    mapCtx.lineTo(targetScreenX, targetScreenY);
    mapCtx.stroke();
    mapCtx.setLineDash([]);
  }
}

function renderMinimap() {
  if (!minimapCtx) return;
  
  const w = minimapCanvas.width;
  const h = minimapCanvas.height;
  const scale = w / WORLD_SIZE;
  
  // Clear
  minimapCtx.fillStyle = '#1a2a1a';
  minimapCtx.fillRect(0, 0, w, h);
  
  // Draw objects
  mapData.forEach(tile => {
    const x = tile.x * scale;
    const y = tile.y * scale;
    
    if (tile.type === 'CITY') {
      minimapCtx.fillStyle = tile.playerId === player?.id ? '#ffd700' : '#c44';
      minimapCtx.fillRect(x - 2, y - 2, 4, 4);
    } else if (tile.type === 'RESOURCE') {
      minimapCtx.fillStyle = '#4a8';
      minimapCtx.fillRect(x - 1, y - 1, 2, 2);
    }
  });
  
  // Draw viewport rectangle
  const viewportEl = document.getElementById('minimap-viewport');
  if (viewportEl) {
    const viewSize = (mapCanvas.width / (TILE_SIZE * mapZoomLevel)) / WORLD_SIZE * 100;
    const left = ((mapOffsetX / WORLD_SIZE) * 100);
    const top = ((mapOffsetY / WORLD_SIZE) * 100);
    
    viewportEl.style.width = `${viewSize}%`;
    viewportEl.style.height = `${viewSize}%`;
    viewportEl.style.left = `${50 + left - viewSize/2}%`;
    viewportEl.style.top = `${50 + top - viewSize/2}%`;
  }
}

function updateMapUI() {
  document.getElementById('map-x').textContent = Math.round(mapOffsetX);
  document.getElementById('map-y').textContent = Math.round(mapOffsetY);
  document.getElementById('zoom-level').textContent = `${Math.round(mapZoomLevel * 100)}%`;
}

// Mouse handlers
function onMapMouseDown(e) {
  mapDragging = true;
  mapDragStart = { x: e.clientX, y: e.clientY };
  mapCanvas.style.cursor = 'grabbing';
}

function onMapMouseMove(e) {
  const rect = mapCanvas.getBoundingClientRect();
  const mouseX = e.clientX - rect.left;
  const mouseY = e.clientY - rect.top;
  
  if (mapDragging) {
    const dx = (e.clientX - mapDragStart.x) / (TILE_SIZE * mapZoomLevel);
    const dy = (e.clientY - mapDragStart.y) / (TILE_SIZE * mapZoomLevel);
    
    mapOffsetX -= dx;
    mapOffsetY -= dy;
    
    mapDragStart = { x: e.clientX, y: e.clientY };
    renderMap();
    renderMinimap();
    updateMapUI();
  } else {
    // Update hovered tile
    const tileSize = TILE_SIZE * mapZoomLevel;
    const tileX = Math.floor(mapOffsetX + (mouseX - mapCanvas.width / 2) / tileSize);
    const tileY = Math.floor(mapOffsetY + (mouseY - mapCanvas.height / 2) / tileSize);
    
    mapHoveredTile = { x: tileX, y: tileY };
    renderMap();
  }
}

function onMapMouseUp() {
  mapDragging = false;
  mapCanvas.style.cursor = 'grab';
}

function onMapClick(e) {
  if (mapDragging) return;
  
  const rect = mapCanvas.getBoundingClientRect();
  const mouseX = e.clientX - rect.left;
  const mouseY = e.clientY - rect.top;
  
  const tileSize = TILE_SIZE * mapZoomLevel;
  const tileX = Math.floor(mapOffsetX + (mouseX - mapCanvas.width / 2) / tileSize);
  const tileY = Math.floor(mapOffsetY + (mouseY - mapCanvas.height / 2) / tileSize);
  
  // Find what's at this tile
  const tile = mapData.find(t => t.x === tileX && t.y === tileY);
  
  mapSelectedTile = { x: tileX, y: tileY };
  showMapInfoPanel(tileX, tileY, tile);
  renderMap();
}

// Touch handlers for mobile
let touchStartDist = 0;
let touchStartZoom = 1;

function onMapTouchStart(e) {
  e.preventDefault();
  
  if (e.touches.length === 2) {
    // Pinch zoom start
    touchStartDist = Math.hypot(
      e.touches[0].clientX - e.touches[1].clientX,
      e.touches[0].clientY - e.touches[1].clientY
    );
    touchStartZoom = mapZoomLevel;
  } else if (e.touches.length === 1) {
    mapDragging = true;
    mapDragStart = { x: e.touches[0].clientX, y: e.touches[0].clientY };
  }
}

function onMapTouchMove(e) {
  e.preventDefault();
  
  if (e.touches.length === 2) {
    // Pinch zoom
    const dist = Math.hypot(
      e.touches[0].clientX - e.touches[1].clientX,
      e.touches[0].clientY - e.touches[1].clientY
    );
    
    mapZoomLevel = Math.max(0.3, Math.min(3, touchStartZoom * (dist / touchStartDist)));
    renderMap();
    renderMinimap();
    updateMapUI();
  } else if (e.touches.length === 1 && mapDragging) {
    const dx = (e.touches[0].clientX - mapDragStart.x) / (TILE_SIZE * mapZoomLevel);
    const dy = (e.touches[0].clientY - mapDragStart.y) / (TILE_SIZE * mapZoomLevel);
    
    mapOffsetX -= dx;
    mapOffsetY -= dy;
    
    mapDragStart = { x: e.touches[0].clientX, y: e.touches[0].clientY };
    renderMap();
    renderMinimap();
    updateMapUI();
  }
}

function onMapTouchEnd() {
  mapDragging = false;
}

// Wheel zoom
function onMapWheel(e) {
  e.preventDefault();
  
  const zoomDelta = e.deltaY > 0 ? -0.1 : 0.1;
  mapZoomLevel = Math.max(0.3, Math.min(3, mapZoomLevel + zoomDelta));
  
  renderMap();
  renderMinimap();
  updateMapUI();
}

// Zoom buttons
function mapZoom(delta) {
  mapZoomLevel = Math.max(0.3, Math.min(3, mapZoomLevel + delta));
  renderMap();
  renderMinimap();
  updateMapUI();
}

function centerOnCapital() {
  const capital = cities.find(c => c.isCapital);
  if (capital) {
    mapOffsetX = capital.x;
    mapOffsetY = capital.y;
  } else {
    mapOffsetX = WORLD_SIZE / 2;
    mapOffsetY = WORLD_SIZE / 2;
  }
  loadMap();
}

function showMapInfoPanel(x, y, tile) {
  const panel = document.getElementById('map-info-panel');
  const content = document.getElementById('map-panel-content');
  
  if (!tile) {
    content.innerHTML = `
      <h3>Terrain vide</h3>
      <p>Position: (${x}, ${y})</p>
      <p style="color:#888">Aucun objet à cet emplacement</p>
    `;
  } else if (tile.type === 'CITY') {
    const isMyCity = tile.playerId === player?.id;
    const canAttack = !isMyCity && armies.some(a => a.status === 'IDLE');
    
    content.innerHTML = `
      <h3>${tile.isCapital ? '👑 ' : ''}${tile.name || 'Ville'}</h3>
      <p>Position: (${x}, ${y})</p>
      <p>Propriétaire: ${isMyCity ? 'Vous' : 'Ennemi'}</p>
      <div class="panel-actions">
        ${isMyCity ? `
          <button class="btn btn-secondary" onclick="goToCity('${tile.id}')">Visiter</button>
        ` : `
          ${canAttack ? `
            <button class="btn btn-danger" onclick="attackFromMap('${tile.id}', ${x}, ${y})">Attaquer</button>
            <button class="btn" style="background:linear-gradient(180deg,orange,#c70)" onclick="raidFromMap('${tile.id}')">Piller</button>
          ` : '<p style="font-size:11px;color:#888">Pas d\'armée disponible</p>'}
        `}
      </div>
    `;
  } else if (tile.type === 'RESOURCE') {
    content.innerHTML = `
      <h3>${tile.resourceType === 'WOOD' ? '🌲 Forêt' : tile.resourceType === 'STONE' ? '⛰️ Carrière' : tile.resourceType === 'IRON' ? '⚒️ Mine' : '🌾 Oasis'}</h3>
      <p>Position: (${x}, ${y})</p>
      <p>Type: ${tile.resourceType}</p>
      <div class="panel-actions">
        <button class="btn btn-secondary" onclick="sendArmyTo(${x}, ${y})">Envoyer armée</button>
      </div>
    `;
  }
  
  panel.style.display = 'block';
}

function closeMapPanel() {
  document.getElementById('map-info-panel').style.display = 'none';
  mapSelectedTile = null;
  renderMap();
}

function goToCity(cityId) {
  const city = cities.find(c => c.id === cityId);
  if (city) {
    currentCity = city;
    showTab('city');
  }
}

function attackFromMap(cityId, x, y) {
  const army = armies.find(a => a.status === 'IDLE' && a.units?.length > 0);
  if (!army) {
    showToast('Aucune armée disponible', 'error');
    return;
  }
  
  document.getElementById('modal-body').innerHTML = `
    <h3>Confirmer l'attaque</h3>
    <p>Envoyer <strong>${army.name}</strong> attaquer la ville à (${x}, ${y}) ?</p>
    <button onclick="confirmAttackFromMap('${army.id}', '${cityId}')" class="btn btn-danger">Attaquer!</button>
    <button onclick="closeModal()" class="btn btn-secondary">Annuler</button>
  `;
  document.getElementById('modal').style.display = 'flex';
}

async function confirmAttackFromMap(armyId, cityId) {
  const res = await fetch(`${API}/api/army/${armyId}/attack`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify({ targetCityId: cityId })
  });
  
  closeModal();
  closeMapPanel();
  
  if (res.ok) {
    showToast('Attaque lancée!', 'success');
    await loadArmies();
    loadMap();
  } else {
    const data = await res.json();
    showToast(data.error || 'Erreur', 'error');
  }
}

function raidFromMap(cityId) {
  const army = armies.find(a => a.status === 'IDLE' && a.units?.length > 0);
  if (army) {
    document.getElementById('modal-body').innerHTML = `
      <h3>Confirmer le raid</h3>
      <p>Envoyer <strong>${army.name}</strong> piller cette ville ?</p>
      <button onclick="confirmRaidFromMap('${army.id}', '${cityId}')" class="btn" style="background:linear-gradient(180deg,orange,#c70)">Piller!</button>
      <button onclick="closeModal()" class="btn btn-secondary">Annuler</button>
    `;
    document.getElementById('modal').style.display = 'flex';
  }
}

async function confirmRaidFromMap(armyId, cityId) {
  const res = await fetch(`${API}/api/army/${armyId}/raid`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify({ targetCityId: cityId })
  });
  
  closeModal();
  closeMapPanel();
  
  if (res.ok) {
    showToast('Raid lancé!', 'success');
    await loadArmies();
    loadMap();
  }
}

async function sendArmyTo(x, y) {
  const army = armies.find(a => a.status === 'IDLE');
  if (!army) {
    showToast('Aucune armée disponible', 'error');
    return;
  }
  
  const res = await fetch(`${API}/api/army/${army.id}/move`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify({ x, y })
  });
  
  closeMapPanel();
  
  if (res.ok) {
    showToast('Armée en route!', 'success');
    await loadArmies();
    loadMap();
  }
}

// Resize handler
window.addEventListener('resize', () => {
  if (mapCanvas && document.getElementById('tab-map').classList.contains('active')) {
    const container = mapCanvas.parentElement;
    mapCanvas.width = container.clientWidth;
    mapCanvas.height = container.clientHeight;
    renderMap();
  }
});

// ========== ALLIANCE ==========
async function loadAlliance() {
  const res = await fetch(`${API}/api/player/me`, { headers: { Authorization: `Bearer ${token}` } });
  const content = document.getElementById('alliance-content');
  
  if (res.ok) {
    const p = await res.json();
    
    if (p.allianceMember) {
      const allianceRes = await fetch(`${API}/api/alliances`, { headers: { Authorization: `Bearer ${token}` } });
      const alliances = await allianceRes.json();
      const myAlliance = alliances.find(a => a.members.some(m => m.playerId === p.id));
      
      if (myAlliance) {
        content.innerHTML = `
          <div class="alliance-header">
            <div class="alliance-emblem">🛡️</div>
            <div class="alliance-info">
              <h3>[${myAlliance.tag}] ${myAlliance.name}</h3>
              <div class="alliance-tag">${myAlliance.members.length} membres</div>
            </div>
          </div>
          <div class="alliance-members">
            ${myAlliance.members.map(m => `
              <div class="member-row">
                <span class="member-name">${m.player.name}</span>
                <span class="member-role ${m.role}">${m.role}</span>
              </div>
            `).join('')}
          </div>
          <button onclick="leaveAlliance()" class="btn btn-danger" style="margin-top:20px">Quitter l'alliance</button>
        `;
        return;
      }
    }
    
    // No alliance
    const alliancesRes = await fetch(`${API}/api/alliances`, { headers: { Authorization: `Bearer ${token}` } });
    const alliances = await alliancesRes.json();
    
    content.innerHTML = `
      <div style="margin-bottom:30px">
        <h3 style="color:var(--gold);margin-bottom:15px">Créer une alliance</h3>
        <input type="text" id="alliance-name" placeholder="Nom de l'alliance" style="width:100%;padding:10px;margin-bottom:10px;background:var(--bg-light);border:1px solid var(--border);color:var(--text);border-radius:4px">
        <input type="text" id="alliance-tag" placeholder="Tag (2-5 caractères)" maxlength="5" style="width:100%;padding:10px;margin-bottom:10px;background:var(--bg-light);border:1px solid var(--border);color:var(--text);border-radius:4px">
        <button onclick="createAlliance()" class="btn">Créer</button>
      </div>
      <h3 style="color:var(--gold);margin-bottom:15px">Rejoindre une alliance</h3>
      ${alliances.slice(0, 10).map(a => `
        <div class="member-row">
          <span class="member-name">[${a.tag}] ${a.name} (${a.members.length} membres)</span>
          <button onclick="joinAlliance('${a.id}')" class="btn btn-secondary" style="margin:0;padding:6px 12px">Rejoindre</button>
        </div>
      `).join('') || '<p style="color:var(--text-muted)">Aucune alliance</p>'}
    `;
  }
}

async function createAlliance() {
  const name = document.getElementById('alliance-name').value;
  const tag = document.getElementById('alliance-tag').value;
  
  const res = await fetch(`${API}/api/alliance/create`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify({ name, tag })
  });
  
  if (res.ok) {
    showToast('Alliance créée!', 'success');
    loadAlliance();
  } else {
    const data = await res.json();
    showToast(data.error || 'Erreur', 'error');
  }
}

async function joinAlliance(id) {
  const res = await fetch(`${API}/api/alliance/${id}/join`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}` }
  });
  
  if (res.ok) {
    showToast('Alliance rejointe!', 'success');
    loadAlliance();
  } else {
    const data = await res.json();
    showToast(data.error || 'Erreur', 'error');
  }
}

async function leaveAlliance() {
  const res = await fetch(`${API}/api/alliance/leave`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}` }
  });
  
  if (res.ok) {
    showToast('Alliance quittée', 'success');
    loadAlliance();
  }
}

// ========== RANKING ==========
async function loadRanking(type) {
  document.querySelectorAll('.rank-tab').forEach(t => t.classList.remove('active'));
  document.querySelector(`.rank-tab:${type === 'players' ? 'first-child' : 'last-child'}`)?.classList.add('active');
  
  const endpoint = type === 'players' ? '/api/ranking/players' : '/api/ranking/alliances';
  const res = await fetch(`${API}${endpoint}`, { headers: { Authorization: `Bearer ${token}` } });
  
  if (res.ok) {
    const data = await res.json();
    const content = document.getElementById('ranking-content');
    
    content.innerHTML = `
      <div class="ranking-list">
        ${data.map((item, i) => `
          <div class="ranking-row">
            <span class="ranking-position ${i < 3 ? 'top' + (i + 1) : ''}">${i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : i + 1}</span>
            <span class="ranking-name">${type === 'players' ? item.name : `[${item.tag}] ${item.name}`}</span>
            <span class="ranking-value">${formatNum(item.population || 0)} pop</span>
          </div>
        `).join('')}
      </div>
    `;
  }
}

function showRanking(type) {
  loadRanking(type);
}

// ========== REPORTS ==========
async function loadReports() {
  const res = await fetch(`${API}/api/reports/battles`, { headers: { Authorization: `Bearer ${token}` } });
  
  if (res.ok) {
    const reports = await res.json();
    const list = document.getElementById('reports-list');
    
    list.innerHTML = reports.length > 0 ? reports.map(r => `
      <div class="report-card">
        <div class="report-header">
          <span class="report-title">⚔️ Bataille à (${r.x}, ${r.y})</span>
          <span class="report-result ${r.winner === 'ATTACKER' ? 'victory' : 'defeat'}">${r.winner === 'ATTACKER' ? 'Victoire' : 'Défaite'}</span>
        </div>
        <div class="report-details">
          <p>Pertes attaquant: ${Math.round((r.attackerLosses?.rate || 0) * 100)}%</p>
          <p>Pertes défenseur: ${Math.round((r.defenderLosses?.rate || 0) * 100)}%</p>
        </div>
        ${r.loot ? `
          <div class="report-loot">
            Butin: 🪵${r.loot.wood || 0} 🪨${r.loot.stone || 0} ⛏️${r.loot.iron || 0} 🌾${r.loot.food || 0}
          </div>
        ` : ''}
      </div>
    `).join('') : '<p style="color:var(--text-muted)">Aucun rapport</p>';
  }
}

// ========== UTILS ==========
function formatNum(n) {
  if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M';
  if (n >= 1000) return (n / 1000).toFixed(1) + 'K';
  return Math.floor(n).toString();
}

function formatTime(dateStr) {
  const date = new Date(dateStr);
  const now = new Date();
  const diff = Math.max(0, date - now);
  
  const hours = Math.floor(diff / 3600000);
  const mins = Math.floor((diff % 3600000) / 60000);
  const secs = Math.floor((diff % 60000) / 1000);
  
  if (hours > 0) return `${hours}h ${mins}m`;
  if (mins > 0) return `${mins}m ${secs}s`;
  return `${secs}s`;
}

function getBuildingName(key) {
  const names = {
    MAIN_HALL: 'Hôtel de ville', BARRACKS: 'Caserne', STABLE: 'Écurie', WORKSHOP: 'Atelier',
    FARM: 'Ferme', LUMBER: 'Scierie', QUARRY: 'Carrière', IRON_MINE: 'Mine',
    WAREHOUSE: 'Entrepôt', SILO: 'Silo', MARKET: 'Marché', ACADEMY: 'Académie',
    FORGE: 'Forge', WALL: 'Mur', MOAT: 'Douves', HEALING_TENT: 'Infirmerie',
    RALLY_POINT: 'Point de ralliement', HIDEOUT: 'Cachette'
  };
  return names[key] || key;
}

function showBuildingInfo(key, level) {
  showToast(`${getBuildingName(key)} niveau ${level}`, 'info');
}

function closeModal() {
  document.getElementById('modal').style.display = 'none';
}

function showToast(msg, type = 'info') {
  const toast = document.getElementById('toast');
  toast.textContent = msg;
  toast.className = `toast ${type} show`;
  setTimeout(() => toast.classList.remove('show'), 3000);
}

// ========== AUTO REFRESH ==========
let refreshInterval;

function startRefresh() {
  refreshInterval = setInterval(async () => {
    await loadCities();
    await loadArmies();
    await loadPlayer();
    if (document.getElementById('tab-city').classList.contains('active')) {
      renderCity();
    }
  }, 10000);
}

// ========== INIT ==========
window.onload = () => {
  if (token) {
    showGame();
  }
};

// Close modal on outside click
document.getElementById('modal')?.addEventListener('click', (e) => {
  if (e.target.id === 'modal') closeModal();
});
