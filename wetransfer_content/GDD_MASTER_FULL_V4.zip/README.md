# GDD MASTER FULL V4 (Tech Dev)

Généré: 2026-01-31T19:12:37.536212
Tick serveur: 30s

## Contenu
- /systems : configs data-driven (monde, ressources, combat/siège, espionnage, alliance/bastion, social/chat, économie, UI)
- /tables  : tables complètes (unités avec étoiles, bâtiments courbes 1-20, coûts recrutement, temps formation)
- completeness_report.json : ce qui est garanti complet vs calculé/estimé

## Notes
- Les tables unités/bâtiments proviennent de MASTER_EXPORT_V3.1 (synchronisé avec monjeu-alpha-v0.1.3).
- Les points de ressource proviennent du patch V3_RESOURCE_POINTS.
